import React, { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { apiFetch } from "@/lib/api";

export interface FilterOptions {
  as_of_date?: string[];
  book_id?: string[];
  legal_entity?: string[];
  asset_class?: string[];
  issuer?: string[];
  sector?: string[];
  rating?: string[];
  exchange?: string[];
  country?: string[];
  trade_currency?: string[];
  maturity_bucket?: string[];
}

export interface FilterValues {
  as_of_date?: string;
  start_date?: string;
  end_date?: string;
  book_id?: string;
  legal_entity?: string;
  asset_class?: string;
  issuer?: string;
  sector?: string;
  rating?: string;
  exchange?: string;
  country?: string;
  trade_currency?: string;
  maturity_bucket?: string;
  [key: string]: string | undefined;
}

interface FilterContextType {
  options: FilterOptions;
  filters: FilterValues;
  setFilter: (key: string, value: string) => void;
  clearFilters: () => void;
  loading: boolean;
  error: string | null;
}

const FilterContext = createContext<FilterContextType | undefined>(undefined);

export function FilterProvider({ children }: { children: ReactNode }) {
  const [options, setOptions] = useState<FilterOptions>({});
  const [filters, setFilters] = useState<FilterValues>({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    apiFetch<FilterOptions>("/meta/filters")
      .then(setOptions)
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const setFilter = (key: string, value: string) => {
    setFilters((prev) => ({ ...prev, [key]: value || undefined }));
  };

  const clearFilters = () => setFilters({});

  return (
    <FilterContext.Provider value={{ options, filters, setFilter, clearFilters, loading, error }}>
      {children}
    </FilterContext.Provider>
  );
}

export function useFilters() {
  const ctx = useContext(FilterContext);
  if (!ctx) throw new Error("useFilters must be used within FilterProvider");
  return ctx;
}
