import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { FilterProvider } from "@/context/FilterContext";
import { AppLayout } from "@/components/layout/AppLayout";
import DashboardPage from "./pages/DashboardPage";
import TradeBlotterPage from "./pages/TradeBlotterPage";
import ExposurePage from "./pages/ExposurePage";
import VarAnalyticsPage from "./pages/VarAnalyticsPage";
import TrendsPage from "./pages/TrendsPage";
import DataQualityPage from "./pages/DataQualityPage";
import AuditTrailPage from "./pages/AuditTrailPage";
import DataDictionaryPage from "./pages/DataDictionaryPage";
import CopilotPage from "./pages/CopilotPage";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <FilterProvider>
        <BrowserRouter>
          <AppLayout>
            <Routes>
              <Route path="/" element={<DashboardPage />} />
              <Route path="/trade-blotter" element={<TradeBlotterPage />} />
              <Route path="/exposure" element={<ExposurePage />} />
              <Route path="/var-analytics" element={<VarAnalyticsPage />} />
              <Route path="/trends" element={<TrendsPage />} />
              <Route path="/data-quality" element={<DataQualityPage />} />
              <Route path="/audit-trail" element={<AuditTrailPage />} />
              <Route path="/data-dictionary" element={<DataDictionaryPage />} />
              <Route path="/copilot" element={<CopilotPage />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </AppLayout>
        </BrowserRouter>
      </FilterProvider>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
