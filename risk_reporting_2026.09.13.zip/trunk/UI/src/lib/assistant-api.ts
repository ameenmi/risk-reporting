import { apiFetch } from "./api";

const BASE_URL = "http://localhost:5000/api/v1";

export interface AssistantSession {
  id: number;
  title?: string;
  created_at?: string;
  updated_at?: string;
}

export interface AssistantMessage {
  id?: number;
  role: "user" | "assistant";
  content?: string;
  message?: string;
  reply?: AssistantReply;
  created_at?: string;
  timestamp?: string;
}

export interface AssistantReply {
  answer_type?: string;
  narrative?: string;
  executive_summary?: string | string[];
  key_findings?: any[];
  exceptions?: any[];
  recommended_actions?: string[];
  next_actions?: string[];
  filters_applied?: Record<string, any>;
  columns_used?: string[];
  data_scope?: Record<string, any>;
  table?: { columns?: string[]; rows?: any[][] };
  error_type?: string;
  impact?: string;
  fix_options?: string[];
  fallback_action?: string;
  [key: string]: any;
}

export interface ChatRequest {
  session_id?: number;
  message: string;
  filters?: Record<string, string | undefined>;
}

export interface ProfilingResult {
  coverage?: any;
  dictionary_sheets?: any;
  entity_mapping?: any;
  validation?: any;
  safe_analyses?: any;
  risky_analyses?: any;
  next_steps?: any;
  [key: string]: any;
}

export async function getSuggestions(): Promise<any> {
  return apiFetch<any>("/assistant/suggestions");
}

export async function getSessions(): Promise<AssistantSession[]> {
  const res = await apiFetch<any>("/assistant/sessions");
  return res?.sessions || res?.data || res?.items || res || [];
}

export async function createSession(): Promise<AssistantSession> {
  const res = await fetch(`${BASE_URL}/assistant/sessions`, { method: "POST", headers: { "Content-Type": "application/json" } });
  if (!res.ok) throw new Error("Failed to create session");
  return res.json();
}

export async function getSessionMessages(sessionId: number): Promise<AssistantMessage[]> {
  const res = await apiFetch<any>(`/assistant/sessions/${sessionId}/messages`);
  return res?.messages || res?.data || res || [];
}

export async function sendChat(body: ChatRequest): Promise<AssistantReply> {
  const res = await fetch(`${BASE_URL}/assistant/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!res.ok) throw new Error(`Chat error: ${res.statusText}`);
  return res.json();
}

export async function profileFile(csvFile?: File, excelFile?: File): Promise<ProfilingResult> {
  const form = new FormData();
  if (csvFile) form.append("csv_file", csvFile);
  if (excelFile) form.append("excel_file", excelFile);
  const res = await fetch(`${BASE_URL}/assistant/intake/profile`, { method: "POST", body: form });
  if (!res.ok) throw new Error("Profiling failed");
  return res.json();
}
