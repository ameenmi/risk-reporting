import {
  LayoutDashboard, Table2, PieChart, TrendingUp, BarChart3,
  ShieldAlert, FileText, Database, Bot
} from "lucide-react";
import { NavLink } from "@/components/NavLink";
import {
  Sidebar, SidebarContent, SidebarGroup, SidebarGroupContent,
  SidebarGroupLabel, SidebarMenu, SidebarMenuButton, SidebarMenuItem, useSidebar,
} from "@/components/ui/sidebar";

const navItems = [
  { title: "Dashboard", url: "/", icon: LayoutDashboard },
  { title: "Trade Blotter", url: "/trade-blotter", icon: Table2 },
  { title: "Exposure", url: "/exposure", icon: PieChart },
  { title: "VaR Analytics", url: "/var-analytics", icon: BarChart3 },
  { title: "Trends", url: "/trends", icon: TrendingUp },
  { title: "Data Quality", url: "/data-quality", icon: ShieldAlert },
  { title: "Audit Trail", url: "/audit-trail", icon: FileText },
  { title: "Data Dictionary", url: "/data-dictionary", icon: Database },
  { title: "Risk Analyst", url: "/copilot", icon: Bot },
];

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";

  return (
    <Sidebar collapsible="icon">
      <SidebarContent>
        <div className="px-4 py-5">
          {!collapsed && (
            <div>
              <h1 className="text-base font-bold text-sidebar-primary-foreground tracking-tight">RiskView</h1>
              <p className="text-[10px] text-sidebar-foreground/60 uppercase tracking-widest mt-0.5">Analytics Platform</p>
            </div>
          )}
          {collapsed && <div className="text-lg font-bold text-sidebar-primary text-center">R</div>}
        </div>
        <SidebarGroup>
          <SidebarGroupLabel className="text-sidebar-foreground/40">Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild>
                    <NavLink
                      to={item.url}
                      end={item.url === "/"}
                      className="hover:bg-sidebar-accent/60"
                      activeClassName="bg-sidebar-accent text-sidebar-primary font-medium"
                    >
                      <item.icon className="mr-2 h-4 w-4" />
                      {!collapsed && <span>{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>
    </Sidebar>
  );
}
