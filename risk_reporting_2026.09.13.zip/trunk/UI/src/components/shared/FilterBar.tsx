import { useFilters } from "@/context/FilterContext";
import { X } from "lucide-react";

interface FilterBarProps {
  fields?: string[];
  showDateRange?: boolean;
}

const FIELD_LABELS: Record<string, string> = {
  as_of_date: "As Of Date",
  book_id: "Book",
  legal_entity: "Legal Entity",
  asset_class: "Asset Class",
  issuer: "Issuer",
  sector: "Sector",
  rating: "Rating",
  exchange: "Exchange",
  country: "Country",
  trade_currency: "Currency",
  maturity_bucket: "Maturity",
};

export function FilterBar({ fields, showDateRange }: FilterBarProps) {
  const { options, filters, setFilter, clearFilters } = useFilters();
  const displayFields = fields || Object.keys(FIELD_LABELS);
  const hasActive = Object.values(filters).some(Boolean);

  return (
    <div className="flex flex-wrap items-center gap-2 rounded-lg border bg-card px-4 py-3 shadow-sm">
      {showDateRange && (
        <>
          <div className="flex flex-col">
            <label className="text-[10px] font-medium text-muted-foreground uppercase mb-0.5">Start</label>
            <input
              type="date"
              value={filters.start_date || ""}
              onChange={(e) => setFilter("start_date", e.target.value)}
              className="rounded-md border bg-background px-2 py-1 text-sm"
            />
          </div>
          <div className="flex flex-col">
            <label className="text-[10px] font-medium text-muted-foreground uppercase mb-0.5">End</label>
            <input
              type="date"
              value={filters.end_date || ""}
              onChange={(e) => setFilter("end_date", e.target.value)}
              className="rounded-md border bg-background px-2 py-1 text-sm"
            />
          </div>
        </>
      )}
      {displayFields.map((field) => {
        const opts = (options as Record<string, string[]>)[field];
        if (!opts?.length) return null;
        return (
          <div key={field} className="flex flex-col">
            <label className="text-[10px] font-medium text-muted-foreground uppercase mb-0.5">{FIELD_LABELS[field] || field}</label>
            <select
              value={filters[field] || ""}
              onChange={(e) => setFilter(field, e.target.value)}
              className="rounded-md border bg-background px-2 py-1 text-sm min-w-[100px]"
            >
              <option value="">All</option>
              {opts.map((o) => <option key={o} value={o}>{o}</option>)}
            </select>
          </div>
        );
      })}
      {hasActive && (
        <button onClick={clearFilters} className="ml-auto inline-flex items-center gap-1 text-xs font-medium text-destructive hover:text-destructive/80">
          <X className="h-3 w-3" /> Clear
        </button>
      )}
    </div>
  );
}
