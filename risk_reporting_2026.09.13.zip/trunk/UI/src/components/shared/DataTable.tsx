import { Download, ChevronLeft, ChevronRight } from "lucide-react";
import { exportToCsv } from "@/lib/format";
import { EmptyState } from "./EmptyState";

interface DataTableProps {
  columns: { key: string; label: string; render?: (val: unknown, row: Record<string, unknown>) => React.ReactNode }[];
  data: Record<string, unknown>[];
  page?: number;
  totalPages?: number;
  onPageChange?: (page: number) => void;
  exportFilename?: string;
  sortBy?: string;
  sortOrder?: string;
  onSort?: (key: string) => void;
}

export function DataTable({ columns, data, page, totalPages, onPageChange, exportFilename, sortBy, sortOrder, onSort }: DataTableProps) {
  if (!data.length) return <EmptyState />;

  return (
    <div className="rounded-lg border bg-card shadow-sm overflow-hidden">
      {exportFilename && (
        <div className="flex items-center justify-end px-4 py-2 border-b bg-secondary/20">
          <button
            onClick={() => exportToCsv(data, exportFilename)}
            className="inline-flex items-center gap-1.5 rounded-md bg-primary/10 px-3 py-1.5 text-xs font-medium text-primary hover:bg-primary/20 transition-colors"
          >
            <Download className="h-3 w-3" /> Export CSV
          </button>
        </div>
      )}
      <div className="overflow-x-auto">
        <table className="data-table">
          <thead>
            <tr>
              {columns.map((col) => (
                <th
                  key={col.key}
                  className={onSort ? "cursor-pointer select-none hover:text-foreground" : ""}
                  onClick={() => onSort?.(col.key)}
                >
                  <span className="inline-flex items-center gap-1">
                    {col.label}
                    {sortBy === col.key && (
                      <span className="text-primary">{sortOrder === "asc" ? "↑" : "↓"}</span>
                    )}
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, i) => (
              <tr key={i}>
                {columns.map((col) => (
                  <td key={col.key}>{col.render ? col.render(row[col.key], row) : String(row[col.key] ?? "—")}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {totalPages && totalPages > 1 && onPageChange && page != null && (
        <div className="flex items-center justify-between px-4 py-3 border-t bg-secondary/10">
          <span className="text-xs text-muted-foreground">Page {page} of {totalPages}</span>
          <div className="flex items-center gap-1">
            <button disabled={page <= 1} onClick={() => onPageChange(page - 1)} className="p-1 rounded hover:bg-secondary disabled:opacity-30">
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button disabled={page >= totalPages} onClick={() => onPageChange(page + 1)} className="p-1 rounded hover:bg-secondary disabled:opacity-30">
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
