import { Inbox } from "lucide-react";

interface EmptyStateProps {
  title?: string;
  description?: string;
}

export function EmptyState({ title = "No data available", description = "There are no records matching your current filters." }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
      <Inbox className="h-12 w-12 mb-4 opacity-40" />
      <p className="text-base font-medium">{title}</p>
      <p className="text-sm mt-1">{description}</p>
    </div>
  );
}
