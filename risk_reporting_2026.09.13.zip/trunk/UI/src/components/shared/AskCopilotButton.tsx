import { Bot } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useFilters } from "@/context/FilterContext";

interface Props {
  prompt: string;
}

export function AskCopilotButton({ prompt }: Props) {
  const navigate = useNavigate();
  return (
    <button
      onClick={() => navigate(`/copilot?prompt=${encodeURIComponent(prompt)}`)}
      className="inline-flex items-center gap-1.5 rounded-md border bg-primary/5 px-3 py-1.5 text-xs font-medium text-primary hover:bg-primary/10 transition-colors"
    >
      <Bot className="h-3.5 w-3.5" /> Ask Agent
    </button>
  );
}
