export function SkeletonCard() {
  return (
    <div className="kpi-card animate-pulse-soft">
      <div className="h-3 w-20 bg-muted rounded mb-3" />
      <div className="h-8 w-32 bg-muted rounded mb-2" />
      <div className="h-3 w-16 bg-muted rounded" />
    </div>
  );
}

export function SkeletonTable({ rows = 5, cols = 6 }: { rows?: number; cols?: number }) {
  return (
    <div className="rounded-lg border bg-card overflow-hidden">
      <div className="bg-secondary/60 px-4 py-3 flex gap-4">
        {Array.from({ length: cols }).map((_, i) => (
          <div key={i} className="h-3 w-24 bg-muted rounded animate-pulse-soft" />
        ))}
      </div>
      {Array.from({ length: rows }).map((_, r) => (
        <div key={r} className="px-4 py-3 flex gap-4 border-b border-border/50">
          {Array.from({ length: cols }).map((_, c) => (
            <div key={c} className="h-3 w-20 bg-muted/60 rounded animate-pulse-soft" />
          ))}
        </div>
      ))}
    </div>
  );
}

export function SkeletonChart() {
  return (
    <div className="rounded-lg border bg-card p-6 animate-pulse-soft">
      <div className="h-4 w-40 bg-muted rounded mb-6" />
      <div className="h-64 bg-muted/40 rounded" />
    </div>
  );
}
