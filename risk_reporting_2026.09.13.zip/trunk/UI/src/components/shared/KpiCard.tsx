import { ReactNode } from "react";

interface KpiCardProps {
  label: string;
  value: string;
  sublabel?: string;
  icon?: ReactNode;
  colorClass?: string;
}

export function KpiCard({ label, value, sublabel, icon, colorClass = "text-primary" }: KpiCardProps) {
  return (
    <div className="kpi-card">
      <div className="flex items-center justify-between mb-2">
        <span className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">{label}</span>
        {icon && <span className={`${colorClass} opacity-70`}>{icon}</span>}
      </div>
      <div className={`text-xl font-bold truncate ${colorClass}`} title={value}>{value}</div>
      {sublabel && <div className="text-xs text-muted-foreground mt-1">{sublabel}</div>}
    </div>
  );
}
