import { useState } from "react";
import { Upload, FileSpreadsheet, Loader2, X, CheckCircle, AlertTriangle } from "lucide-react";
import { profileFile, type ProfilingResult } from "@/lib/assistant-api";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger
} from "@/components/ui/dialog";

function Section({ title, data, variant }: { title: string; data: any; variant?: "success" | "warning" }) {
  if (!data || (Array.isArray(data) && !data.length) || (typeof data === "object" && !Object.keys(data).length)) return null;
  const icon = variant === "warning" ? <AlertTriangle className="h-4 w-4 text-warning" /> : <CheckCircle className="h-4 w-4 text-kpi-green" />;
  return (
    <div className="rounded-lg border bg-card p-4">
      <div className="flex items-center gap-2 mb-2">{icon}<h4 className="text-sm font-semibold">{title}</h4></div>
      {Array.isArray(data) ? (
        <ul className="space-y-1">{data.map((d, i) => <li key={i} className="text-xs text-muted-foreground">{typeof d === "string" ? d : JSON.stringify(d)}</li>)}</ul>
      ) : typeof data === "object" ? (
        <div className="space-y-1">{Object.entries(data).map(([k, v]) => (
          <div key={k} className="flex justify-between text-xs"><span className="text-muted-foreground">{k}</span><span className="font-medium">{String(v)}</span></div>
        ))}</div>
      ) : <p className="text-xs text-muted-foreground">{String(data)}</p>}
    </div>
  );
}

export function FileProfilingDialog() {
  const [open, setOpen] = useState(false);
  const [csvFile, setCsvFile] = useState<File | null>(null);
  const [excelFile, setExcelFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<ProfilingResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async () => {
    if (!csvFile && !excelFile) return;
    setLoading(true); setError(null);
    try {
      const res = await profileFile(csvFile || undefined, excelFile || undefined);
      setResult(res);
    } catch (e: any) { setError(e.message); }
    finally { setLoading(false); }
  };

  const reset = () => { setCsvFile(null); setExcelFile(null); setResult(null); setError(null); };

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) reset(); }}>
      <DialogTrigger asChild>
        <button className="inline-flex items-center gap-1.5 rounded-md border bg-card px-3 py-1.5 text-xs font-medium hover:bg-secondary transition-colors">
          <Upload className="h-3.5 w-3.5" /> Intake & Profile
        </button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileSpreadsheet className="h-5 w-5 text-primary" /> File Intake & Profiling
          </DialogTitle>
        </DialogHeader>

        {!result ? (
          <div className="space-y-4 py-2">
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">CSV File</label>
              <input type="file" accept=".csv" onChange={(e) => setCsvFile(e.target.files?.[0] || null)}
                className="block w-full text-sm file:mr-3 file:rounded-md file:border-0 file:bg-primary/10 file:px-3 file:py-1.5 file:text-xs file:font-medium file:text-primary" />
            </div>
            <div>
              <label className="text-xs font-medium text-muted-foreground mb-1 block">Excel File</label>
              <input type="file" accept=".xlsx,.xls" onChange={(e) => setExcelFile(e.target.files?.[0] || null)}
                className="block w-full text-sm file:mr-3 file:rounded-md file:border-0 file:bg-primary/10 file:px-3 file:py-1.5 file:text-xs file:font-medium file:text-primary" />
            </div>
            {error && <p className="text-xs text-destructive">{error}</p>}
            <button onClick={handleSubmit} disabled={loading || (!csvFile && !excelFile)}
              className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90 disabled:opacity-50 transition-colors">
              {loading ? <><Loader2 className="h-4 w-4 animate-spin" /> Profiling…</> : "Run Profiling"}
            </button>
          </div>
        ) : (
          <div className="space-y-3 py-2">
            <Section title="Coverage" data={result.coverage} variant="success" />
            <Section title="Dictionary Sheets" data={result.dictionary_sheets} />
            <Section title="Entity Mapping" data={result.entity_mapping} />
            <Section title="Validation" data={result.validation} variant={result.validation?.issues ? "warning" : "success"} />
            <Section title="Safe Analyses" data={result.safe_analyses} variant="success" />
            <Section title="Risky Analyses" data={result.risky_analyses} variant="warning" />
            <Section title="Next Steps" data={result.next_steps} />
            <button onClick={reset} className="text-xs text-primary hover:underline">← Upload another file</button>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
