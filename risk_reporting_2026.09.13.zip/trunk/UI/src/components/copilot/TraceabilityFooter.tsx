import type { AssistantReply } from "@/lib/assistant-api";

export function TraceabilityFooter({ reply }: { reply: AssistantReply }) {
  const parts: string[] = [];
  if (reply.filters_applied) {
    const active = Object.entries(reply.filters_applied).filter(([, v]) => v != null);
    if (active.length) parts.push(`Filters: ${active.map(([k, v]) => `${k}=${v}`).join(", ")}`);
  }
  if (reply.columns_used?.length) parts.push(`Cols: ${reply.columns_used.length}`);
  if (reply.data_scope?.row_count) parts.push(`Rows: ${reply.data_scope.row_count}`);
  if (reply.data_scope?.total_rows) parts.push(`Rows: ${reply.data_scope.total_rows}`);

  if (!parts.length) return null;
  return (
    <div className="mt-2 flex flex-wrap gap-2 text-[10px] text-muted-foreground/70">
      {parts.map((p, i) => (
        <span key={i} className="rounded bg-muted/50 px-1.5 py-0.5">{p}</span>
      ))}
    </div>
  );
}
