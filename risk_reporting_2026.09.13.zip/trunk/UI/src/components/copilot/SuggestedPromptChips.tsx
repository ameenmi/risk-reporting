import { Sparkles } from "lucide-react";

interface Props {
  suggestions: string[];
  onSelect: (prompt: string) => void;
}

export function SuggestedPromptChips({ suggestions, onSelect }: Props) {
  if (!suggestions.length) return null;
  return (
    <div className="flex flex-wrap gap-2">
      {suggestions.map((s, i) => (
        <button
          key={i}
          onClick={() => onSelect(s)}
          className="inline-flex items-center gap-1.5 rounded-full border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground hover:bg-secondary hover:text-foreground transition-colors"
        >
          <Sparkles className="h-3 w-3 text-accent" />
          {s}
        </button>
      ))}
    </div>
  );
}
