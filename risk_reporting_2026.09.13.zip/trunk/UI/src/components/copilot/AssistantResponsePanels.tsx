import {
  FileText, AlertTriangle, ArrowRight, Filter, Columns, Database, CheckCircle
} from "lucide-react";
import type { AssistantReply } from "@/lib/assistant-api";

function PanelCard({ title, icon, children, variant }: {
  title: string; icon: React.ReactNode; children: React.ReactNode; variant?: "success" | "warning" | "info";
}) {
  const border = variant === "warning" ? "border-warning/30 bg-warning/5" :
    variant === "success" ? "border-kpi-green/30 bg-kpi-green/5" : "border-border";
  return (
    <div className={`rounded-lg border ${border} bg-card p-4 shadow-sm`}>
      <div className="flex items-center gap-2 mb-3">
        {icon}
        <h4 className="text-sm font-semibold text-foreground">{title}</h4>
      </div>
      {children}
    </div>
  );
}

export function ExecutiveSummaryPanel({ summary }: { summary?: string | string[] }) {
  if (!summary) return null;
  const items = Array.isArray(summary) ? summary : [summary];
  return (
    <PanelCard title="Executive Summary" icon={<FileText className="h-4 w-4 text-primary" />}>
      <ul className="space-y-2">
        {items.map((s, i) => (
          <li key={i} className="text-sm text-muted-foreground leading-relaxed">{s}</li>
        ))}
      </ul>
    </PanelCard>
  );
}

export function FindingsPanel({ findings }: { findings?: any[] }) {
  if (!findings?.length) return null;
  return (
    <PanelCard title="Key Findings" icon={<CheckCircle className="h-4 w-4 text-kpi-green" />} variant="success">
      <ul className="space-y-2">
        {findings.map((f, i) => (
          <li key={i} className="text-sm text-muted-foreground">
            {typeof f === "string" ? f : (
              <div>
                {f.title && <span className="font-medium text-foreground">{f.title}: </span>}
                {f.description || f.detail || f.value || JSON.stringify(f)}
              </div>
            )}
          </li>
        ))}
      </ul>
    </PanelCard>
  );
}

export function ExceptionsPanel({ exceptions }: { exceptions?: any[] }) {
  if (!exceptions?.length) return null;
  return (
    <PanelCard title="Exceptions & Data Quality Notes" icon={<AlertTriangle className="h-4 w-4 text-warning" />} variant="warning">
      <ul className="space-y-1">
        {exceptions.map((e, i) => (
          <li key={i} className="text-sm text-muted-foreground">
            {typeof e === "string" ? e : e.message || e.detail || JSON.stringify(e)}
          </li>
        ))}
      </ul>
    </PanelCard>
  );
}

export function NextActionsPanel({ actions }: { actions?: string[] }) {
  if (!actions?.length) return null;
  return (
    <PanelCard title="Recommended Next Actions" icon={<ArrowRight className="h-4 w-4 text-accent" />}>
      <ol className="space-y-1 list-decimal list-inside">
        {actions.map((a, i) => (
          <li key={i} className="text-sm text-muted-foreground">{a}</li>
        ))}
      </ol>
    </PanelCard>
  );
}

export function FiltersAppliedPanel({ filters }: { filters?: Record<string, any> }) {
  if (!filters || !Object.keys(filters).length) return null;
  return (
    <PanelCard title="Filters Applied" icon={<Filter className="h-4 w-4 text-muted-foreground" />}>
      <div className="flex flex-wrap gap-2">
        {Object.entries(filters).map(([k, v]) => v != null && (
          <span key={k} className="inline-flex items-center rounded-full bg-secondary px-2.5 py-0.5 text-xs font-medium">
            {k.replace(/_/g, " ")}: {String(v)}
          </span>
        ))}
      </div>
    </PanelCard>
  );
}

export function ColumnsUsedPanel({ columns }: { columns?: string[] }) {
  if (!columns?.length) return null;
  return (
    <PanelCard title="Columns Used" icon={<Columns className="h-4 w-4 text-muted-foreground" />}>
      <div className="flex flex-wrap gap-1.5">
        {columns.map((c, i) => (
          <span key={i} className="rounded bg-muted px-2 py-0.5 text-xs font-mono">{c}</span>
        ))}
      </div>
    </PanelCard>
  );
}

export function DataScopePanel({ scope }: { scope?: Record<string, any> }) {
  if (!scope || !Object.keys(scope).length) return null;
  return (
    <PanelCard title="Data Scope" icon={<Database className="h-4 w-4 text-muted-foreground" />}>
      <div className="space-y-1">
        {Object.entries(scope).map(([k, v]) => (
          <div key={k} className="flex justify-between text-xs">
            <span className="text-muted-foreground">{k.replace(/_/g, " ")}</span>
            <span className="font-medium text-foreground">{String(v)}</span>
          </div>
        ))}
      </div>
    </PanelCard>
  );
}

export function AssistantTableRenderer({ table }: { table?: { columns?: string[]; rows?: any[][] } }) {
  if (!table?.rows?.length) return null;
  const columns = Object.keys(table.rows[0])
  return (
    <div className="rounded-lg border bg-card shadow-sm overflow-hidden">
      <div className="overflow-x-auto">
        <table className="data-table">
          <thead>
            <tr>
              {(columns || []).map((c, i) => <th key={i}>{c}</th>)}
            </tr>
          </thead>
          <tbody>
            {table.rows.map((row, ri) => (
              <tr key={ri}>
                {Object.keys(row).map((cell, ci) => <td key={ci}>{String(row[cell] ?? "—")}</td>)}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export function ErrorResponsePanel({ reply }: { reply: AssistantReply }) {
  if (reply.answer_type !== "error") return null;
  return (
    <PanelCard title={`Error: ${reply.error_type || "Unknown"}`} icon={<AlertTriangle className="h-4 w-4 text-destructive" />} variant="warning">
      <div className="space-y-2 text-sm">
        {reply.impact && <p><span className="font-medium">Impact:</span> {reply.impact}</p>}
        {reply.fix_options?.length && (
          <div>
            <span className="font-medium">Fix options:</span>
            <ul className="list-disc list-inside mt-1">
              {reply.fix_options.map((f, i) => <li key={i}>{f}</li>)}
            </ul>
          </div>
        )}
        {reply.fallback_action && <p className="text-muted-foreground italic">{reply.fallback_action}</p>}
      </div>
    </PanelCard>
  );
}

export function ResponseInsightsPanel({ reply }: { reply: AssistantReply }) {
  return (
    <div className="space-y-4">
      {reply.answer_type === "error" && <ErrorResponsePanel reply={reply} />}
      {/* <ExecutiveSummaryPanel summary={reply.executive_summary} /> */}
      {/* <FindingsPanel findings={reply.key_findings} /> */}
      <ExceptionsPanel exceptions={reply.exceptions} />
      <NextActionsPanel actions={reply.recommended_actions || reply.next_actions} />
      <AssistantTableRenderer table={reply.table} />
      <FiltersAppliedPanel filters={reply.filters_applied} />
      <ColumnsUsedPanel columns={reply.columns_used} />
      {/* <DataScopePanel scope={reply.data_scope} /> */}
    </div>
  );
}
