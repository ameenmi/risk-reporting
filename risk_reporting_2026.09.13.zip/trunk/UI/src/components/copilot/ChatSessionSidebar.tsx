import { Plus, MessageSquare } from "lucide-react";
import type { AssistantSession } from "@/lib/assistant-api";

interface Props {
  sessions: AssistantSession[];
  activeId?: number;
  onSelect: (id: number) => void;
  onCreate: () => void;
  loading?: boolean;
}

export function ChatSessionSidebar({ sessions, activeId, onSelect, onCreate, loading }: Props) {
  return (
    <div className="flex flex-col h-full border-r bg-secondary/20">
      <div className="p-3 border-b">
        <button
          onClick={onCreate}
          className="w-full inline-flex items-center justify-center gap-2 rounded-md bg-primary px-3 py-2 text-xs font-medium text-primary-foreground hover:bg-primary/90 transition-colors"
        >
          <Plus className="h-3.5 w-3.5" /> New Session
        </button>
      </div>
      <div className="flex-1 overflow-y-auto p-2 space-y-1">
        {loading && <div className="text-xs text-muted-foreground p-2">Loading…</div>}
        {sessions.map((s) => (
          <button
            key={s.id}
            onClick={() => onSelect(s.id)}
            className={`w-full text-left rounded-md px-3 py-2 text-xs transition-colors flex items-center gap-2 ${
              activeId === s.id ? "bg-primary/10 text-primary font-medium" : "hover:bg-secondary text-muted-foreground"
            }`}
          >
            <MessageSquare className="h-3.5 w-3.5 shrink-0" />
            <span className="truncate">{s.title || `Session #${s.id}`}</span>
          </button>
        ))}
      </div>
    </div>
  );
}
