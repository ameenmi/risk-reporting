import { useState } from "react";
import { useApi } from "@/hooks/useApi";
import { useFilters } from "@/context/FilterContext";
import { FilterBar } from "@/components/shared/FilterBar";
import { ErrorBanner } from "@/components/shared/ErrorBanner";
import { SkeletonChart } from "@/components/shared/Skeletons";
import { EmptyState } from "@/components/shared/EmptyState";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, Legend } from "recharts";

const METRICS = ["market_value", "market_value_var", "component_var", "marginal_var", "delta", "cs01"];
const GROUP_OPTIONS = ["", "book_id", "asset_class", "issuer", "sector", "rating", "trade_currency", "maturity_bucket", "legal_entity"];
const COLORS = ["#1e3a5f", "#0891b2", "#059669", "#ea580c", "#7c3aed", "#dc2626", "#64748b", "#d97706"];

export default function TrendsPage() {
  const { filters } = useFilters();
  const [metric, setMetric] = useState("market_value");
  const [groupBy, setGroupBy] = useState("");

  const params: Record<string, string> = { ...filters, metric };
  if (groupBy) params.group_by = groupBy;

  const { data, loading, error, refetch } = useApi<any>("/reports/trends", params);
  const series = data?.series || data?.data || [];

  // If grouped, data may have multiple series keys
  const seriesKeys = series.length > 0
    ? Object.keys(series[0]).filter((k) => k !== "date" && k !== "as_of_date")
    : [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h1 className="page-title">Trends</h1>
        <div className="flex items-center gap-3">
          <div className="flex flex-col">
            <span className="text-[10px] font-medium text-muted-foreground uppercase mb-0.5">Metric</span>
            <select value={metric} onChange={(e) => setMetric(e.target.value)} className="rounded-md border bg-card px-3 py-1.5 text-sm">
              {METRICS.map((m) => <option key={m} value={m}>{m.replace(/_/g, " ")}</option>)}
            </select>
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] font-medium text-muted-foreground uppercase mb-0.5">Group by</span>
            <select value={groupBy} onChange={(e) => setGroupBy(e.target.value)} className="rounded-md border bg-card px-3 py-1.5 text-sm">
              <option value="">None</option>
              {GROUP_OPTIONS.filter(Boolean).map((g) => <option key={g} value={g}>{g.replace(/_/g, " ")}</option>)}
            </select>
          </div>
        </div>
      </div>
      <FilterBar fields={["as_of_date", "book_id", "legal_entity", "asset_class"]} />
      {error && <ErrorBanner message={error} onRetry={refetch} />}
      {loading ? <SkeletonChart /> : series.length === 0 ? <EmptyState /> : (
        <div className="rounded-lg border bg-card p-6 shadow-sm">
          <ResponsiveContainer width="100%" height={450}>
            <LineChart data={series}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(214,25%,88%)" />
              <XAxis dataKey={series[0]?.date !== undefined ? "date" : "as_of_date"} tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip />
              <Legend />
              {seriesKeys.map((key, i) => (
                <Line key={key} type="monotone" dataKey={key} stroke={COLORS[i % COLORS.length]} strokeWidth={2} dot={false} />
              ))}
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}
