import { useState, useEffect, useRef, useCallback } from "react";
import { Send, Loader2, Bot, User, ToggleLeft, ToggleRight } from "lucide-react";
import { useFilters } from "@/context/FilterContext";
import {
  getSuggestions, getSessions, createSession, getSessionMessages, sendChat,
  type AssistantSession, type AssistantMessage, type AssistantReply
} from "@/lib/assistant-api";
import { ChatSessionSidebar } from "@/components/copilot/ChatSessionSidebar";
import { SuggestedPromptChips } from "@/components/copilot/SuggestedPromptChips";
import { ResponseInsightsPanel } from "@/components/copilot/AssistantResponsePanels";
import { TraceabilityFooter } from "@/components/copilot/TraceabilityFooter";
import { FileProfilingDialog } from "@/components/copilot/FileProfilingDialog";
import { useSearchParams } from "react-router-dom";
//import ReactMarkdown from "react-markdown";

function escapeHtml(value: any): string {
  if (typeof value === "string" || typeof value === "number") {
    return String(value);
  }
  return "";
}


function isObjectArray(arr: any[]): boolean {
  return arr.every(item => typeof item === "object" && item !== null && !Array.isArray(item));
}

function renderObjectTable(
  data: Record<string, any>[],
  title: string
): string {
  const columns = Object.keys(data[0] || {});
  const tableId = `table-${Math.random().toString(36).slice(2)}`;

  return `
  <div class="flex items-center justify-between mb-2">
    <h4 class="mt-4 mb-2 text-sm font-semibold">${escapeHtml(title)}</h4>
    <button
          onclick="window.__exportTableToCSV('${tableId}')"
          title="Export to CSV"
          class="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground transition-colors"
        >
          <!-- CSV / Download icon -->
          <svg xmlns="http://www.w3.org/2000/svg"
               class="h-4 w-4"
               fill="none"
               viewBox="0 0 24 24"
               stroke="currentColor">
            <path stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M12 3v12m0 0l-4-4m4 4l4-4M4 17v2a2 2 0 002 2h12a2 2 0 002-2v-2" />
          </svg>
          <span class="text-xs">CSV</span>
        </button>
    </div>
    <div
      class="relative max-w-full overflow-x-auto overflow-y-auto 
             rounded-md border border-border bg-background

             [&::-webkit-scrollbar]:h-2
             [&::-webkit-scrollbar]:w-2
             [&::-webkit-scrollbar-track]:bg-transparent
             [&::-webkit-scrollbar-thumb]:bg-muted-foreground/40
             [&::-webkit-scrollbar-thumb]:rounded-full
             hover:[&::-webkit-scrollbar-thumb]:bg-muted-foreground/60"
    >
      <table id="${tableId}" class="min-w-full w-max border-collapse text-xs mb-0 mt-0">
        <thead class="sticky top-0 bg-muted z-10">
          <tr>
            ${columns
              .map(
                col => `
                  <th class="px-3 py-2 text-left font-medium
                           border-b border-border whitespace-nowrap">
                    ${escapeHtml(col)}
                  </th>`
              )
              .join("")}
          </tr>
        </thead>
        <tbody>
          ${data
            .map(
              row => `
                <tr class="hover:bg-muted/50 transition-colors">
                  ${columns
                    .map(
                      col => `
                        <td class="px-3 py-2 border-b border-border whitespace-nowrap">
                          ${escapeHtml(row[col] ?? "—")}
                        </td>`
                    )
                    .join("")}
                </tr>`
            )
            .join("")}
        </tbody>
      </table>
    </div>
  `;
}


function renderPrimitiveList(items: any[], title: string): string {
  return `
    <h4 class="mt-4 mb-2 text-sm font-semibold">${escapeHtml(title)}</h4>
    <ul class="list-disc ml-5 space-y-1">
      ${items.map(i => `<li>${escapeHtml(i)}</li>`).join("")}
    </ul>
  `;
}



function buildAssistantContent(reply: any): string {

  let html = "";

  if (reply?.title) {
    html += `<h3>${escapeHtml(reply.title)}</h3>`;
  }

  if (reply?.executive_summary?.length) {
    html += `<h4>Executive Summary</h4><ul>`;
    reply.executive_summary.forEach((s: any) => {
      html += `<li>${escapeHtml(s)}</li>`;
    });
    html += `</ul>`;
  }

  if (reply?.narrative) {
    html += `<h4>Narrative</h4><p>${escapeHtml(reply.narrative)}</p>`;
  }

 if (Array.isArray(reply?.key_findings) && reply.key_findings.length > 0) {
      if (isObjectArray(reply.key_findings)) {
        html += renderObjectTable(reply.key_findings, "Key Findings");
      } else {
        html += renderPrimitiveList(reply.key_findings, "Key Findings");
      }
    }

  if (reply?.table?.rows?.length) {
    const columns = Object.keys(reply.table.rows[0]);
    const tableId = `table-${Math.random().toString(36).slice(2)}`;

    html += `
      
<div class="flex items-center justify-between mb-2 mt-2">
        <h4 class="text-sm font-semibold">Data Table</h4>

        <button
          onclick="window.__exportTableToCSV('${tableId}')"
          title="Export to CSV"
          class="inline-flex items-center gap-1 text-muted-foreground hover:text-foreground transition-colors"
        >
          <!-- CSV / Download icon -->
          <svg xmlns="http://www.w3.org/2000/svg"
               class="h-4 w-4"
               fill="none"
               viewBox="0 0 24 24"
               stroke="currentColor">
            <path stroke-linecap="round"
                  stroke-linejoin="round"
                  stroke-width="2"
                  d="M12 3v12m0 0l-4-4m4 4l4-4M4 17v2a2 2 0 002 2h12a2 2 0 002-2v-2" />
          </svg>
          <span class="text-xs">CSV</span>
        </button>
      </div>

     <div
        class="relative max-w-full overflow-x-auto overflow-y-auto
              rounded-md border border-border bg-background
              [&::-webkit-scrollbar]:h-2
              [&::-webkit-scrollbar]:w-2
              [&::-webkit-scrollbar-track]:bg-transparent
              [&::-webkit-scrollbar-thumb]:bg-muted-foreground/40
              [&::-webkit-scrollbar-thumb]:rounded-full
              hover:[&::-webkit-scrollbar-thumb]:bg-muted-foreground/60"
      >
        <table id="${tableId}" class="min-w-full w-max border-collapse text-xs mb-0 mt-0">
          <thead class="sticky top-0 bg-muted z-10">
            <tr>
              ${columns
                .map(
                  col =>
                    `<th class="px-3 py-2 text-left font-medium border-b border-border whitespace-nowrap">
                      ${escapeHtml(col)}
                    </th>`
                )
                .join("")}
            </tr>
          </thead>

          <tbody>
            ${reply.table.rows
              .map(
                (row: any) => `
                  <tr class="hover:bg-muted/50 transition-colors">
                    ${columns
                      .map(
                        col =>
                          `<td class="px-3 py-2 border-b border-border whitespace-nowrap">
                            ${escapeHtml(row[col] ?? "—")}
                          </td>`
                      )
                      .join("")}
                  </tr>
                `
              )
              .join("")}
          </tbody>
        </table>
      </div>
    `;

  }

  if (reply?.recommended_next_actions?.length) {
    html += `<h4>Recommended Next Actions</h4><ul>`;
    reply.recommended_next_actions.forEach((a: any) => {
      html += `<li>${escapeHtml(a)}</li>`;
    });
    html += `</ul>`;
  }

  if (reply?.source_notice) {
    html += `<h4>Source</h4><p>${escapeHtml(reply.source_notice)}</p>`;
  }

  return html;
}


function mapApiMessagesToChatMessages(apiMessages: any[]): AssistantMessage[] {
  return apiMessages.map((item) => {
    if (item.role === "assistant") {
      const parsedReply = item.response_json
        ? JSON.parse(item.response_json)
        : null;

      return {
        role: "assistant",
        content: buildAssistantContent(parsedReply),
        reply: parsedReply, 
      };
    }

    // user message
    return {
      role: "user",
      content: item.content,
    };
  });
}


export default function CopilotPage() {
  const { filters } = useFilters();
  const [searchParams] = useSearchParams();
  const prefilled = searchParams.get("prompt");

  const [sessions, setSessions] = useState<AssistantSession[]>([]);
  const [activeSession, setActiveSession] = useState<number | undefined>();
  const [messages, setMessages] = useState<AssistantMessage[]>([]);
  const [input, setInput] = useState(prefilled || "");
  const [sending, setSending] = useState(false);
  const [useFiltersToggle, setUseFiltersToggle] = useState(true);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [sessionsLoading, setSessionsLoading] = useState(true);
  const [selectedReply, setSelectedReply] = useState<AssistantReply | null>(null);

  const scrollRef = useRef<HTMLDivElement>(null);

  // Load sessions + suggestions on mount
  useEffect(() => {
    getSessions().then(setSessions).catch(() => {}).finally(() => setSessionsLoading(false));
    getSuggestions().then((r) => {
      const items = r?.suggestions || r?.data || r || [];
      setSuggestions(Array.isArray(items) ? items.map((s: any) => typeof s === "string" ? s : s.prompt || s.text || "") : []);
    }).catch(() => {});
  }, []);

  // Load messages when session changes
  useEffect(() => {
    if (!activeSession) { setMessages([]); return; }
    getSessionMessages(activeSession).then((data) => {
      setMessages([]);
        mapApiMessagesToChatMessages(data).forEach((msg) => {
          
          setMessages((prev) => [...prev, msg]);
        })
    }).catch(() => setMessages([]));
  }, [activeSession]);

  // Auto-scroll
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  // Auto-send prefilled prompt
  useEffect(() => {
    if (prefilled && !sending) {
      setInput(prefilled);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prefilled]);

  
  useEffect(() => {
    (window as any).__exportTableToCSV = exportTableToCSV;

    return () => {
      delete (window as any).__exportTableToCSV;
    };
  }, []);


  const handleCreateSession = useCallback(async () => {
    try {
      const s = await createSession();
      setSessions((prev) => [s, ...prev]);
      setActiveSession(s.id);
      setMessages([]);
      setSelectedReply(null);
    } catch {}
  }, []);

  const handleSend = useCallback(async (text?: string) => {
    const msg = text || input.trim();
    if (!msg || sending) return;

    setSending(true);
    setInput("");

    const userMsg: AssistantMessage = { role: "user", content: msg };
    setMessages((prev) => [...prev, userMsg]);

    try {
      const cleanFilters = useFiltersToggle ? Object.fromEntries(
        Object.entries(filters).filter(([, v]) => v !== undefined)
      ) : {};

      const replyRes = await sendChat({
        session_id: activeSession,
        message: msg,
        filters: cleanFilters,
      });
      const {reply} = replyRes;
      const assistantMsg: AssistantMessage = {
        role: "assistant",
        content: buildAssistantContent(reply),
        reply,
      };
      setMessages((prev) => [...prev, assistantMsg]);
      setSelectedReply(reply);

      if (!activeSession && reply && (reply as any).session_id) {
        setActiveSession((reply as any).session_id);
        getSessions().then(setSessions).catch(() => {});
      }
    } catch (e: any) {
      setMessages((prev) => [...prev, { role: "assistant", content: `Error: ${e.message}` }]);
    } finally {
      setSending(false);
    }
  }, [input, sending, activeSession, filters, useFiltersToggle]);

  const exportTableToCSV = (tableId) => {
    
  const table = document.getElementById(tableId);
    if (!table) return;

    const rows = Array.from(table.querySelectorAll("tr"));

    const csvRows: string[] = [];

    for (const row of rows) {
      const cells = Array.from(
        row.querySelectorAll<HTMLTableCellElement>("th, td")
      );

      if (cells.length === 0) continue;

      const csvRow = cells
        .map(cell => {
          let value = cell.textContent ?? "";

          // ✅ Normalize whitespace
          value = value.replace(/\s+/g, " ").trim();

          // ✅ Escape double quotes
          value = value.replace(/"/g, '""');

          // ✅ Wrap in quotes (CSV-safe)
          return `"${value}"`;
        })
        .join(",");

        csvRows.push(csvRow);
      }

      // ✅ Add UTF‑8 BOM for Excel compatibility
      const csvContent = "\uFEFF" + csvRows.join("\n");

      const blob = new Blob([csvContent], {
        type: "text/csv;charset=utf-8;",
      });

      const url = URL.createObjectURL(blob);

      const link = document.createElement("a");
      link.href = url;
      link.download = `risk-summary-${new Date().toISOString().slice(0,10)}.csv`;
      link.click();

      URL.revokeObjectURL(url);

  };

  return (
    <div className="flex h-[calc(100vh-3rem)] -m-6">
      {/* Session sidebar */}
      <div className="w-56 shrink-0">
        <ChatSessionSidebar
          sessions={sessions}
          activeId={activeSession}
          onSelect={(id) => { setActiveSession(id); setSelectedReply(null); }}
          onCreate={handleCreateSession}
          loading={sessionsLoading}
        />
      </div>

      {/* Chat panel */}
      <div className="flex-1 flex flex-col min-w-0 border-r">
        {/* Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b bg-card">
          <div className="flex items-center gap-2">
            <Bot className="h-5 w-5 text-primary" />
            <h2 className="text-sm font-semibold">Risk Reporting Copilot</h2>
          </div>
          <div className="flex items-center gap-3">
            <FileProfilingDialog />
            <button
              onClick={() => setUseFiltersToggle(!useFiltersToggle)}
              className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
              title="Attach dashboard filters to chat"
            >
              {useFiltersToggle ? <ToggleRight className="h-4 w-4 text-primary" /> : <ToggleLeft className="h-4 w-4" />}
              Filters
            </button>
          </div>
        </div>

        {/* Messages */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.length === 0 && (
            <div className="flex flex-col items-center justify-center h-full gap-4 text-center">
              <Bot className="h-12 w-12 text-muted-foreground/30" />
              <div>
                <p className="text-sm font-medium text-muted-foreground">Risk Reporting Copilot</p>
                <p className="text-xs text-muted-foreground/70 mt-1">Ask questions about your risk data, exposure, VaR, and more.</p>
              </div>
              {suggestions.length > 0 && (
                <SuggestedPromptChips suggestions={suggestions} onSelect={(s) => handleSend(s)} />
              )}
            </div>
          )}

          {messages.map((m, i) => (
            <div key={i} className={`flex gap-3 ${m.role === "user" ? "justify-end" : ""}`}>
              {m.role === "assistant" && (
                <div className="shrink-0 h-7 w-7 rounded-full bg-primary/10 flex items-center justify-center">
                  <Bot className="h-4 w-4 text-primary" />
                </div>
              )}
              <div
                className={`max-w-[87%] rounded-lg px-4 py-3 text-sm ${
                  m.role === "user"
                    ? "bg-primary text-primary-foreground"
                    : "bg-secondary/50 text-foreground hover:bg-secondary/70 transition-colors"
                }`}
                /* onClick={() => m.reply && setSelectedReply(m.reply)} */
              >
                <div className={`prose prose-sm max-w-none prose-p:my-1 prose-headings:my-2 ${m.role === "user" ? "text-white" : ""}`}
                dangerouslySetInnerHTML={{ __html: m.content || m.message || "" }}
                >
                 {/*  <ReactMarkdown 
                  remarkPlugins={[remarkGfm]}
                  rehypePlugins={[rehypeRaw]}
                  >
                    {m.content || m.message || ""}
                  </ReactMarkdown> */}

                </div>
                {m.reply && <TraceabilityFooter reply={m.reply} />}
              </div>
              {m.role === "user" && (
                <div className="shrink-0 h-7 w-7 rounded-full bg-muted flex items-center justify-center">
                  <User className="h-4 w-4 text-muted-foreground" />
                </div>
              )}
            </div>
          ))}

          {sending && (
            <div className="flex gap-3">
              <div className="shrink-0 h-7 w-7 rounded-full bg-primary/10 flex items-center justify-center">
                <Bot className="h-4 w-4 text-primary" />
              </div>
              <div className="rounded-lg bg-secondary/50 px-4 py-3">
                <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
              </div>
            </div>
          )}
        </div>

        {/* Suggestions bar if messages exist */}
        {messages.length > 0 && suggestions.length > 0 && (
          <div className="px-4 py-2 border-t bg-card/50">
            <SuggestedPromptChips suggestions={suggestions.slice(0, 4)} onSelect={(s) => handleSend(s)} />
          </div>
        )}

        {/* Composer */}
        <div className="border-t bg-card p-3">
          <div className="flex items-center gap-2">
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
              placeholder="Ask about risk data, exposure, VaR…"
              className="flex-1 rounded-md border bg-background px-3 py-2 text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring"
              disabled={sending}
            />
            <button
              onClick={() => handleSend()}
              disabled={sending || !input.trim()}
              className="rounded-md bg-primary p-2 text-primary-foreground hover:bg-primary/90 disabled:opacity-50 transition-colors"
            >
              <Send className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Right insights panel */}
      {/*<div className="w-96 shrink-0 overflow-y-auto p-4 bg-secondary/10">
        { {selectedReply ? (
          <ResponseInsightsPanel reply={selectedReply} />
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-center gap-2">
            <Bot className="h-10 w-10 text-muted-foreground/20" />
            <p className="text-xs text-muted-foreground/60">Contextual insights will appear here when you interact with the assistant.</p>
          </div>
        )} }
      </div>*/}
    </div>
  );
}
