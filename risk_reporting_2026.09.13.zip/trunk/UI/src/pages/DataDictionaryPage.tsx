import { useApi } from "@/hooks/useApi";
import { ErrorBanner } from "@/components/shared/ErrorBanner";
import { SkeletonTable } from "@/components/shared/Skeletons";
import { EmptyState } from "@/components/shared/EmptyState";


type SheetDetail = {
  attributes: string[];
  row_count: number;
};

type DataDictionaryResponse = {
  mandatory_fields: string[];
  sheets: string[];
  sheet_details: Record<string, SheetDetail>;
};

export default function DataDictionaryPage() {
  const { data, loading, error, refetch } =
    useApi<DataDictionaryResponse>("/meta/data-dictionary");

  if (loading) return <SkeletonTable rows={6} />;
  if (error) return <ErrorBanner message={error} onRetry={refetch} />;
  if (!data) return <EmptyState title="No data available" />;

  const { mandatory_fields, sheets, sheet_details } = data;

  return (
    <div className="space-y-8">
      {/* Page Title */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold text-gray-900">
          Data Dictionary
        </h1>
      </div>

      {/* Mandatory Fields */}
      <div className="bg-white border border-gray-200 rounded-xl shadow-sm p-6">
        <h2 className="text-lg font-medium text-gray-900 mb-3">
          Mandatory Fields
        </h2>

        <div className="flex flex-wrap gap-2">
          {mandatory_fields.map((field: string) => (
            <span
              key={field}
              className="px-3 py-1 rounded-full bg-gray-100 text-sm text-gray-700"
            >
              {field}
            </span>
          ))}
        </div>
      </div>

      {/* Sheets Table */}
      <div className="bg-white border border-gray-200 rounded-xl shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-gray-200">
          <h2 className="text-lg font-medium text-gray-900">
            Sheets Overview
          </h2>
        </div>

        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              {["Sheet", "Rows", "Attributes"].map((h) => (
                <th
                  key={h}
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wide"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>

          <tbody className="bg-white divide-y divide-gray-200">
            {sheets.map((sheet: string) => {
              const detail = sheet_details[sheet];
              return (
                <tr key={sheet} className="hover:bg-gray-50">
                  <td className="px-6 py-4 text-sm font-medium text-gray-900">
                    {sheet}
                  </td>

                  <td className="px-6 py-4 text-sm text-gray-600">
                    {detail?.row_count ?? "—"}
                  </td>

                  <td className="px-6 py-4 text-sm text-gray-600">
                    {detail?.attributes?.join(", ") || "—"}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Per‑sheet detail cards */}
      {sheets.map((sheet: string) => {
        const detail = sheet_details[sheet];
        if (!detail) return null;

        return (
          <div
            key={sheet}
            className="bg-white border border-gray-200 rounded-xl shadow-sm p-6"
          >
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              {sheet}
            </h3>

            <p className="text-sm text-gray-500 mb-4">
              {detail.row_count} rows
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
              {detail.attributes.map((attr: string) => (
                <div
                  key={attr}
                  className="px-3 py-2 rounded-lg bg-gray-50 text-sm text-gray-700"
                >
                  {attr}
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}