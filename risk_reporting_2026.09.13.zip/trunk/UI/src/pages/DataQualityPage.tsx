import { useApi } from "@/hooks/useApi";
import { ErrorBanner } from "@/components/shared/ErrorBanner";
import { SkeletonCard } from "@/components/shared/Skeletons";
import { KpiCard } from "@/components/shared/KpiCard";
import { formatNumber } from "@/lib/format";
import { AlertTriangle, CheckCircle, XCircle } from "lucide-react";
import { AskCopilotButton } from "@/components/shared/AskCopilotButton";

export default function DataQualityPage() {
  const { data, loading, error, refetch } = useApi<any>("/reports/data-quality");

  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="page-title">Data Quality</h1>
        <AskCopilotButton prompt="Review data quality issues and suggest remediation steps" />
      </div>

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      ) : !data ? (
        <div className="text-muted-foreground">No data quality information available.</div>
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <KpiCard label="Row Count" value={formatNumber(data.row_count)} icon={<CheckCircle className="h-4 w-4" />} colorClass="text-kpi-teal" />
            <KpiCard
              label="Missing Mandatory Cols"
              value={Array.isArray(data.missing_mandatory_columns) ? String(data.missing_mandatory_columns.length) : String(data.missing_mandatory_columns ?? 0)}
              icon={data.missing_mandatory_columns?.length ? <XCircle className="h-4 w-4" /> : <CheckCircle className="h-4 w-4" />}
              colorClass={data.missing_mandatory_columns?.length ? "text-destructive" : "text-kpi-green"}
            />
            <KpiCard
              label="Duplicate Keys"
              value={formatNumber(data.duplicate_date_trade_keys)}
              icon={data.duplicate_date_trade_keys > 0 ? <AlertTriangle className="h-4 w-4" /> : <CheckCircle className="h-4 w-4" />}
              colorClass={data.duplicate_date_trade_keys > 0 ? "text-warning" : "text-kpi-green"}
            />
          </div>

          {/* Missing mandatory columns detail */}
          {Array.isArray(data.missing_mandatory_columns) && data.missing_mandatory_columns.length > 0 && (
            <div className="error-banner">
              <XCircle className="h-5 w-5 shrink-0" />
              <div>
                <p className="font-medium text-sm">Missing Mandatory Columns</p>
                <p className="text-xs mt-1">{data.missing_mandatory_columns.join(", ")}</p>
              </div>
            </div>
          )}

          {/* Mandatory Null Counts */}
          {data.mandatory_null_counts && Object.keys(data.mandatory_null_counts).length > 0 && (
            <div className="rounded-lg border bg-card p-5 shadow-sm">
              <h3 className="section-title mb-3">Mandatory Field Null Counts</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                {Object.entries(data.mandatory_null_counts).map(([field, count]) => (
                  <div key={field} className="flex items-center justify-between rounded-md border px-3 py-2">
                    <span className="text-sm font-medium">{field}</span>
                    <span className={`text-sm font-bold ${(count as number) > 0 ? "text-destructive" : "text-kpi-green"}`}>{String(count)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Invalid Values */}
          {data.invalid_asset_class_values?.length > 0 && (
            <div className="rounded-lg border border-warning/30 bg-warning/5 p-5">
              <h3 className="text-sm font-semibold text-warning mb-2">Invalid Asset Class Values</h3>
              <p className="text-xs text-muted-foreground">{data.invalid_asset_class_values.join(", ")}</p>
            </div>
          )}

          {data.invalid_buy_sell_values?.length > 0 && (
            <div className="rounded-lg border border-warning/30 bg-warning/5 p-5">
              <h3 className="text-sm font-semibold text-warning mb-2">Invalid Buy/Sell Values</h3>
              <p className="text-xs text-muted-foreground">{data.invalid_buy_sell_values.join(", ")}</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
