import { useState } from "react";
import { useApi } from "@/hooks/useApi";
import { useFilters } from "@/context/FilterContext";
import { FilterBar } from "@/components/shared/FilterBar";
import { KpiCard } from "@/components/shared/KpiCard";
import { DataTable } from "@/components/shared/DataTable";
import { ErrorBanner } from "@/components/shared/ErrorBanner";
import { SkeletonCard, SkeletonTable } from "@/components/shared/Skeletons";
import { formatCompact, formatCurrency, formatPercent, formatNumber } from "@/lib/format";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { AskCopilotButton } from "@/components/shared/AskCopilotButton";

const GROUP_OPTIONS = ["issuer", "asset_class", "sector", "rating", "book_id", "legal_entity", "trade_currency", "maturity_bucket"];

export default function VarAnalyticsPage() {
  const { filters } = useFilters();
  const [contribGroup, setContribGroup] = useState("issuer");

  const { data, loading, error, refetch } = useApi<any>("/reports/var-summary", filters);
  const { data: contribData, loading: contribLoading } = useApi<any>("/reports/var-contribution", { ...filters, group_by: contribGroup });

  const contribItems = contribData?.items || contribData?.data || [];
  const summary = data?.summary || {};
  const topContributors = data?.top_component_var_contributors || [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="page-title">VaR Analytics</h1>
        <AskCopilotButton prompt="Explain the top VaR contributors and any unusual risk concentrations" />
      </div>
      <FilterBar fields={["as_of_date", "book_id", "legal_entity", "asset_class"]} />
      {error && <ErrorBanner message={error} onRetry={refetch} />}

      {loading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          {Array.from({ length: 7 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      ) : data && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KpiCard label="Total MV VaR" value={formatCompact(summary.total_market_value_var)} colorClass="text-kpi-orange" />
          <KpiCard label="Avg MV VaR" value={formatCompact(summary.average_market_value_var)} colorClass="text-kpi-orange" />
          <KpiCard label="Total Marginal VaR" value={formatCompact(summary.total_marginal_var)} colorClass="text-kpi-teal" />
          <KpiCard label="Avg Marginal VaR" value={formatCompact(summary.average_marginal_var)} colorClass="text-kpi-teal" />
          <KpiCard label="Total Comp VaR" value={formatCompact(summary.total_component_var)} colorClass="text-kpi-purple" />
          <KpiCard label="Avg Comp VaR" value={formatCompact(summary.average_component_var)} colorClass="text-kpi-purple" />
          <KpiCard label="Sum % Contrib" value={formatPercent(summary.sum_pct_contribution)} colorClass="text-kpi-slate" />
          <KpiCard label="Trade Count" value={formatNumber(summary.trade_count)} colorClass="text-kpi-slate" />
        </div>
      )}

      {topContributors.length > 0 && (
        <div>
          <h3 className="section-title mb-3">Top Component VaR Contributors</h3>
          <DataTable
            columns={[
              { key: "book_id", label: "Instrument" },
              { key: "trade_id", label: "Trade" },
              { key: "asset_class", label: "Class" },
              { key: "component_var", label: "Comp VaR", render: (v) => formatCurrency(v as number) },
              { key: "pct_contribution", label: "% Contrib", render: (v) => formatPercent(v as number) },
            ]}
            data={topContributors}
            exportFilename="var_top_contributors.csv"
          />
        </div>
      )}

      <div>
        <div className="flex items-center justify-between mb-3 flex-wrap gap-3">
          <h3 className="section-title">VaR Contribution by Group</h3>
          <select value={contribGroup} onChange={(e) => setContribGroup(e.target.value)} className="rounded-md border bg-card px-3 py-1.5 text-sm">
            {GROUP_OPTIONS.map((g) => <option key={g} value={g}>{g.replace(/_/g, " ")}</option>)}
          </select>
        </div>
        {contribLoading ? <SkeletonTable /> : contribItems.length > 0 ? (
          <>
            <div className="rounded-lg border bg-card p-6 shadow-sm mb-4">
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={contribItems.slice(0, 15)}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(214,25%,88%)" />
                  <XAxis dataKey="group_value" tick={{ fontSize: 10 }} angle={-30} textAnchor="end" height={60} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="component_var" fill="#7c3aed" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            <DataTable
              columns={[
                { key: "group_value", label: "Group" },
                { key: "component_var", label: "Comp VaR", render: (v) => formatCurrency(v as number) },
                { key: "pct_contribution", label: "% Contrib", render: (v) => formatPercent(v as number) },
              ]}
              data={contribItems}
              exportFilename="var_contribution.csv"
            />
          </>
        ) : <DataTable columns={[]} data={[]} />}
      </div>
    </div>
  );
}
