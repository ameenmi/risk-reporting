import { useState } from "react";
import { useApi } from "@/hooks/useApi";
import { DataTable } from "@/components/shared/DataTable";
import { ErrorBanner } from "@/components/shared/ErrorBanner";
import { SkeletonTable } from "@/components/shared/Skeletons";

export default function AuditTrailPage() {
  const [page, setPage] = useState(1);
  const { data, loading, error, refetch } = useApi<any>("/audit-logs", { page: String(page) });

  return (
    <div className="space-y-6">
      <h1 className="page-title">Audit Trail</h1>
      {error && <ErrorBanner message={error} onRetry={refetch} />}
      {loading ? <SkeletonTable rows={10} cols={5} /> : (
        <DataTable
          columns={[
            { key: "created_at", label: "Timestamp" },
            { key: "event_type", label: "Event Type" },
            { key: "endpoint", label: "Endpoint" },
            { key: "actor", label: "Actor" },
            { key: "details", label: "Details", render: (v) => typeof v === "object" ? JSON.stringify(v) : String(v ?? "—") },
          ]}
          data={data?.items || data?.data || []}
          page={page}
          totalPages={data?.total_pages || 1}
          onPageChange={setPage}
          exportFilename="audit_trail.csv"
        />
      )}
    </div>
  );
}
