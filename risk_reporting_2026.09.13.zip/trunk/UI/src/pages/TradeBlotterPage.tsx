import { useState } from "react";
import { useApi } from "@/hooks/useApi";
import { useFilters } from "@/context/FilterContext";
import { FilterBar } from "@/components/shared/FilterBar";
import { DataTable } from "@/components/shared/DataTable";
import { ErrorBanner } from "@/components/shared/ErrorBanner";
import { SkeletonTable } from "@/components/shared/Skeletons";
import { formatCurrency, formatNumber, formatPercent } from "@/lib/format";

const COLUMNS = [
  { key: "as_of_date", label: "Date" },
  { key: "trade_id", label: "Trade ID" },
  { key: "book_id", label: "Book" },
  { key: "legal_entity", label: "Entity" },
  { key: "instrument_id", label: "Instrument" },
  { key: "asset_class", label: "Class" },
  { key: "buy_sell", label: "B/S" },
  { key: "quantity", label: "Qty", render: (v: unknown) => formatNumber(v as number) },
  { key: "market_value", label: "Market Value", render: (v: unknown) => formatCurrency(v as number) },
  { key: "trade_currency", label: "Ccy" },
  { key: "issuer", label: "Issuer" },
  { key: "sector", label: "Sector" },
  { key: "rating", label: "Rating" },
  { key: "maturity_bucket", label: "Maturity" },
  { key: "market_value_var", label: "MV VaR", render: (v: unknown) => formatCurrency(v as number) },
  { key: "marginal_var", label: "Marginal VaR", render: (v: unknown) => formatCurrency(v as number) },
  { key: "component_var", label: "Comp VaR", render: (v: unknown) => formatCurrency(v as number) },
  { key: "pct_contribution", label: "% Contrib", render: (v: unknown) => formatPercent(v as number) },
];

export default function TradeBlotterPage() {
  const { filters } = useFilters();
  const [page, setPage] = useState(1);
  const [sortBy, setSortBy] = useState("as_of_date");
  const [sortOrder, setSortOrder] = useState("desc");

  const params = { ...filters, page: String(page), sort_by: sortBy, sort_order: sortOrder };
  const { data, loading, error, refetch } = useApi<any>("/reports/trade-blotter", params);

  const handleSort = (key: string) => {
    if (sortBy === key) setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    else { setSortBy(key); setSortOrder("asc"); }
    setPage(1);
  };

  return (
    <div className="space-y-6">
      <h1 className="page-title">Trade Blotter</h1>
      <FilterBar showDateRange fields={["as_of_date", "book_id", "legal_entity", "asset_class", "issuer", "sector", "rating", "exchange", "country", "trade_currency", "maturity_bucket"]} />
      {error && <ErrorBanner message={error} onRetry={refetch} />}
      {loading ? <SkeletonTable rows={10} cols={8} /> : (
        <DataTable
          columns={COLUMNS}
          data={data?.items || data?.data || []}
          page={page}
          totalPages={data?.total_pages || 1}
          onPageChange={setPage}
          exportFilename="trade_blotter.csv"
          sortBy={sortBy}
          sortOrder={sortOrder}
          onSort={handleSort}
        />
      )}
    </div>
  );
}
