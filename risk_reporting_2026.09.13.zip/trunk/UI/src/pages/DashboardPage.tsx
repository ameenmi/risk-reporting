import { useApi } from "@/hooks/useApi";
import { useFilters } from "@/context/FilterContext";
import { KpiCard } from "@/components/shared/KpiCard";
import { ErrorBanner } from "@/components/shared/ErrorBanner";
import { SkeletonCard, SkeletonChart } from "@/components/shared/Skeletons";
import { EmptyState } from "@/components/shared/EmptyState";
import { formatCompact, formatNumber } from "@/lib/format";
import { FilterBar } from "@/components/shared/FilterBar";
import { DataTable } from "@/components/shared/DataTable";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  LineChart, Line, CartesianGrid, Legend
} from "recharts";
import { Activity, DollarSign, TrendingUp, BarChart3, Layers, Calendar } from "lucide-react";
import { AskCopilotButton } from "@/components/shared/AskCopilotButton";

const CHART_COLORS = ["#1e3a5f", "#0891b2", "#059669", "#ea580c", "#7c3aed", "#dc2626", "#64748b", "#d97706"];

export default function DashboardPage() {
  const { filters } = useFilters();
  const { data, loading, error, refetch } = useApi<any>("/reports/dashboard", filters);
  const { data: narrative } = useApi<any>("/analytics/narrative", filters);

  if (error) return <ErrorBanner message={error} onRetry={refetch} />;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="page-title">Dashboard</h1>
        <AskCopilotButton prompt="Summarize the current dashboard overview including key risk metrics and notable exposures" />
      </div>
      <FilterBar fields={["as_of_date", "book_id", "legal_entity", "asset_class"]} />

      {loading ? (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Array.from({ length: 7 }).map((_, i) => <SkeletonCard key={i} />)}
          </div>
          <div className="grid lg:grid-cols-2 gap-6"><SkeletonChart /><SkeletonChart /></div>
        </>
      ) : !data ? (
        <EmptyState />
      ) : (
        <>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <KpiCard label="Trade Count" value={formatNumber(data.overview?.trade_count)} icon={<Activity className="h-4 w-4" />} />
            <KpiCard label="Market Value" value={formatCompact(data.overview?.market_value)} icon={<DollarSign className="h-4 w-4" />} colorClass="text-kpi-teal" />
            <KpiCard label="MV VaR" value={formatCompact(data.overview?.market_value_var)} icon={<TrendingUp className="h-4 w-4" />} colorClass="text-kpi-orange" />
            <KpiCard label="Component VaR" value={formatCompact(data.overview?.component_var)} icon={<BarChart3 className="h-4 w-4" />} colorClass="text-kpi-purple" />
            <KpiCard label="Delta" value={formatNumber(data.overview?.delta, 2)} icon={<Layers className="h-4 w-4" />} colorClass="text-kpi-green" />
            <KpiCard label="CS01" value={formatNumber(data.overview?.cs01, 2)} colorClass="text-kpi-red" />
            <KpiCard label="Latest Date" value={data.overview?.latest_available_date || "—"} icon={<Calendar className="h-4 w-4" />} colorClass="text-kpi-slate" />
          </div>

          {/* Narrative */}
          {narrative?.narrative && (
            <div className="narrative-panel">
              <h3 className="section-title mb-3">Executive Summary</h3>
              <p className="text-muted-foreground leading-relaxed whitespace-pre-line">{narrative.narrative}</p>
            </div>
          )}

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Asset Class Exposure */}
            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="section-title mb-4">Asset Class Exposure</h3>
              {data.asset_class_exposure?.items?.length ? (
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={data.asset_class_exposure.items}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(214,25%,88%)" />
                    <XAxis dataKey="group_value" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Bar dataKey="market_value" fill={CHART_COLORS[0]} radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              ) : <EmptyState title="No exposure data" />}
            </div>

            {/* Market Value Trend */}
            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="section-title mb-4">Market Value Trend</h3>
              {data.market_value_trend?.series?.length ? (
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={data.market_value_trend.series}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(214,25%,88%)" />
                    <XAxis dataKey="as_of_date" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip />
                    <Line type="monotone" dataKey="value" stroke={CHART_COLORS[1]} strokeWidth={2} dot={false} />
                  </LineChart>
                </ResponsiveContainer>
              ) : <EmptyState title="No trend data" />}
            </div>
          </div>

          {/* Top VaR Contributors */}
          {data.var_summary?.top_component_var_contributors?.length > 0 && (
            <div>
              <h3 className="section-title mb-3">Top Component VaR Contributors</h3>
              <DataTable
                columns={[
                  { key: "trade_id", label: "Trade" },
                  { key: "asset_class", label: "Class" },
                  { key: "book_id", label: "Book" },
                  { key: "issuer", label: "Issuer" },
                  { key: "market_value", label: "Market Value", render: (v) => formatCompact(v as number) },
                  { key: "component_var", label: "Component VaR", render: (v) => formatCompact(v as number) },
                  { key: "pct_contribution", label: "% Contribution", render: (v) => `${((v as number) * 100).toFixed(2)}%` },
                ]}
                data={data.var_summary.top_component_var_contributors}
              />
            </div>
          )}
        </>
      )}
    </div>
  );
}
