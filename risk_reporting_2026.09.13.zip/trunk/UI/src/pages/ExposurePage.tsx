import { useState } from "react";
import { useApi } from "@/hooks/useApi";
import { useFilters } from "@/context/FilterContext";
import { FilterBar } from "@/components/shared/FilterBar";
import { DataTable } from "@/components/shared/DataTable";
import { ErrorBanner } from "@/components/shared/ErrorBanner";
import { SkeletonTable, SkeletonChart } from "@/components/shared/Skeletons";
import { formatCurrency, formatNumber, formatPercent } from "@/lib/format";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { AskCopilotButton } from "@/components/shared/AskCopilotButton";

const GROUP_OPTIONS = [
  "asset_class", "issuer", "sector", "rating", "trade_currency",
  "maturity_bucket", "book_id", "legal_entity", "exchange", "country"
];

const COLUMNS = [
  { key: "group_value", label: "Group" },
  { key: "trade_count", label: "Trades", render: (v: unknown) => formatNumber(v as number) },
  { key: "quantity", label: "Qty", render: (v: unknown) => formatNumber(v as number) },
  { key: "market_value", label: "Market Value", render: (v: unknown) => formatCurrency(v as number) },
  { key: "market_value_var", label: "MV VaR", render: (v: unknown) => formatCurrency(v as number) },
  { key: "component_var", label: "Comp VaR", render: (v: unknown) => formatCurrency(v as number) },
  { key: "delta", label: "Delta", render: (v: unknown) => formatNumber(v as number, 2) },
  { key: "cs01", label: "CS01", render: (v: unknown) => formatNumber(v as number, 2) },
  { key: "pct_of_market_value", label: "% of MV", render: (v: unknown) => formatPercent(v as number) },
];

export default function ExposurePage() {
  const { filters } = useFilters();
  const [groupBy, setGroupBy] = useState("asset_class");

  const { data, loading, error, refetch } = useApi<any>("/reports/exposure", { ...filters, group_by: groupBy });
  const items = data?.items || data?.data || [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h1 className="page-title">Exposure Analytics</h1>
        <AskCopilotButton prompt="Analyze the current exposure breakdown and highlight concentration risks" />
        <div className="flex items-center gap-2">
          <span className="text-xs font-medium text-muted-foreground uppercase">Group by</span>
          <select value={groupBy} onChange={(e) => setGroupBy(e.target.value)} className="rounded-md border bg-card px-3 py-1.5 text-sm">
            {GROUP_OPTIONS.map((g) => <option key={g} value={g}>{g.replace(/_/g, " ")}</option>)}
          </select>
        </div>
      </div>
      <FilterBar fields={["as_of_date", "book_id", "legal_entity"]} />
      {error && <ErrorBanner message={error} onRetry={refetch} />}
      {loading ? <><SkeletonChart /><SkeletonTable /></> : (
        <>
          {items.length > 0 && (
            <div className="rounded-lg border bg-card p-6 shadow-sm">
              <h3 className="section-title mb-4">Exposure by {groupBy.replace(/_/g, " ")}</h3>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={items.slice(0, 20)}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(214,25%,88%)" />
                  <XAxis dataKey="group_value" tick={{ fontSize: 10 }} angle={-30} textAnchor="end" height={60} />
                  <YAxis tick={{ fontSize: 11 }} />
                  <Tooltip />
                  <Bar dataKey="market_value" fill="#1e3a5f" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
          <DataTable columns={COLUMNS} data={items} exportFilename="exposure.csv" />
        </>
      )}
    </div>
  );
}
