import sys

sys.path.insert(0,'/cro_data/cro_solutions/services/risk-backend-vectorstore-agent')

from app import create_app

application = create_app()

