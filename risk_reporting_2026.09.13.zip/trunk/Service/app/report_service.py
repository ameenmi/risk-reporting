from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import pandas as pd
from flask import current_app
from sqlalchemy import asc, desc, func

from .extensions import db
from .metadata_service import MANDATORY_EXPECTED
from .models import ImportBatch, PositionSnapshot


CSV_TO_MODEL_MAP = {
    "date": "as_of_date",
    "trade_id": "trade_id",
    "book_id": "book_id",
    "legal_entity": "legal_entity",
    "instrument_id": "instrument_id",
    "asset_class": "asset_class",
    "buy_sell": "buy_sell",
    "quantity": "quantity",
    "market_value": "market_value",
    "currency_x": "trade_currency",
    "currency": "trade_currency",
    "currency_y": "reporting_currency",
    "trading_book_flag": "trading_book_flag",
    "delta": "delta",
    "modified_duration": "modified_duration",
    "convexity": "convexity",
    "cs01": "cs01",
    "krd_1y": "krd_1y",
    "krd_2y": "krd_2y",
    "krd_5y": "krd_5y",
    "krd_10y": "krd_10y",
    "fx_delta": "fx_delta",
    "market_value_var": "market_value_var",
    "marginal_var": "marginal_var",
    "component_var": "component_var",
    "pct_contribution": "pct_contribution",
    "isin": "isin",
    "ticker": "ticker",
    "exchange": "exchange",
    "country": "country",
    "sector": "sector",
    "issuer": "issuer",
    "corporate_actions_flag": "corporate_actions_flag",
    "coupon_type": "coupon_type",
    "coupon_rate": "coupon_rate",
    "coupon_frequency": "coupon_frequency",
    "maturity_date": "maturity_date",
    "day_count": "day_count",
    "embedded_option": "embedded_option",
    "seniority": "seniority",
    "rating": "rating",
}

NUMERIC_COLUMNS = [
    "quantity",
    "market_value",
    "delta",
    "modified_duration",
    "convexity",
    "cs01",
    "krd_1y",
    "krd_2y",
    "krd_5y",
    "krd_10y",
    "fx_delta",
    "market_value_var",
    "marginal_var",
    "component_var",
    "pct_contribution",
    "coupon_rate",
]

BOOLEAN_COLUMNS = ["trading_book_flag", "corporate_actions_flag", "embedded_option"]
DATE_COLUMNS = ["date", "maturity_date"]
ALLOWED_GROUP_FIELDS = {
    "asset_class",
    "issuer",
    "sector",
    "rating",
    "trade_currency",
    "maturity_bucket",
    "book_id",
    "legal_entity",
    "exchange",
    "country",
}
ALLOWED_TREND_METRICS = {
    "market_value",
    "market_value_var",
    "component_var",
    "marginal_var",
    "delta",
    "cs01",
}


def parse_date(value: Any):
    if value in (None, "") or pd.isna(value):
        return None
    ts = pd.to_datetime(value, errors="coerce")
    if pd.isna(ts):
        return None
    return ts.date()



def parse_bool(value: Any):
    if value in (None, "") or pd.isna(value):
        return None
    if isinstance(value, bool):
        return value
    value = str(value).strip().lower()
    if value in {"true", "1", "yes", "y"}:
        return True
    if value in {"false", "0", "no", "n"}:
        return False
    return None



def derive_maturity_bucket(as_of_date, maturity_date):
    if not as_of_date or not maturity_date:
        return "N/A"
    years = max((maturity_date - as_of_date).days, 0) / 365.25
    if years < 1:
        return "<1Y"
    if years < 3:
        return "1Y-3Y"
    if years < 5:
        return "3Y-5Y"
    if years < 10:
        return "5Y-10Y"
    return "10Y+"



def load_dataframe_from_csv(path_or_buffer) -> pd.DataFrame:
    df = pd.read_csv(path_or_buffer)
    df.columns = [str(col).strip() for col in df.columns]
    return df



def normalize_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    frame = df.copy()
    for col in NUMERIC_COLUMNS:
        if col in frame.columns:
            frame[col] = pd.to_numeric(frame[col], errors="coerce")
    for col in BOOLEAN_COLUMNS:
        if col in frame.columns:
            frame[col] = frame[col].apply(parse_bool)
    for col in DATE_COLUMNS:
        if col in frame.columns:
            frame[col] = frame[col].apply(parse_date)
    for col in frame.columns:
        if col not in NUMERIC_COLUMNS and col not in BOOLEAN_COLUMNS and col not in DATE_COLUMNS:
            frame[col] = frame[col].where(frame[col].notna(), None)
    if "date" in frame.columns:
        frame["maturity_bucket"] = frame.apply(
            lambda row: derive_maturity_bucket(row.get("date"), row.get("maturity_date")),
            axis=1,
        )
    else:
        frame["maturity_bucket"] = "N/A"
    return frame



def dataset_quality_summary(df: pd.DataFrame) -> Dict[str, Any]:
    missing_columns = sorted(field for field in MANDATORY_EXPECTED if field not in set(df.columns) and not (field == "currency" and "currency_x" in df.columns))
    duplicate_keys = int(df.duplicated(subset=["date", "trade_id"]).sum()) if {"date", "trade_id"}.issubset(df.columns) else 0
    nulls = {}
    for field in MANDATORY_EXPECTED:
        actual = field
        if field == "currency" and "currency_x" in df.columns:
            actual = "currency_x"
        if actual in df.columns:
            nulls[actual] = int(df[actual].isna().sum())
    invalid_asset = []
    if "asset_class" in df.columns:
        invalid_asset = sorted(set(df["asset_class"].dropna().astype(str)) - {"Equity", "Bond"})
    invalid_side = []
    if "buy_sell" in df.columns:
        invalid_side = sorted(set(df["buy_sell"].dropna().astype(str)) - {"Buy", "Sell"})
    return {
        "row_count": int(len(df)),
        "missing_mandatory_columns": missing_columns,
        "duplicate_date_trade_keys": duplicate_keys,
        "mandatory_null_counts": nulls,
        "invalid_asset_class_values": invalid_asset,
        "invalid_buy_sell_values": invalid_side,
    }



def dataframe_scope_summary(df: pd.DataFrame) -> Dict[str, Any]:
    summary = {
        "row_count": int(len(df)),
        "unique_trades": int(df["trade_id"].nunique()) if "trade_id" in df.columns else 0,
        "unique_books": int(df["book_id"].nunique()) if "book_id" in df.columns else 0,
        "asset_classes": sorted(df["asset_class"].dropna().astype(str).unique().tolist()) if "asset_class" in df.columns else [],
        "date_range": {
            "min": None,
            "max": None,
        },
    }
    if "date" in df.columns:
        parsed = pd.to_datetime(df["date"], errors="coerce")
        if parsed.notna().any():
            summary["date_range"] = {
                "min": parsed.min().date().isoformat(),
                "max": parsed.max().date().isoformat(),
            }
    return summary



def upsert_positions_from_dataframe(df: pd.DataFrame, filename: str, replace_existing: bool = True):
    normalized = normalize_dataframe(df)
    quality = dataset_quality_summary(normalized)
    batch = ImportBatch(filename=filename, status="processing", replace_existing=replace_existing)
    db.session.add(batch)
    db.session.commit()
    try:
        if replace_existing and "date" in normalized.columns:
            dates = sorted(set([value for value in normalized["date"].dropna().tolist()]))
            if dates:
                db.session.query(PositionSnapshot).filter(PositionSnapshot.as_of_date.in_(dates)).delete(synchronize_session=False)
                db.session.commit()
        records = []
        for row in normalized.to_dict(orient="records"):
            payload = {}
            for source_col, target_col in CSV_TO_MODEL_MAP.items():
                if source_col in row:
                    payload[target_col] = row.get(source_col)
            payload["maturity_bucket"] = row.get("maturity_bucket")
            records.append(PositionSnapshot(**payload))
        db.session.bulk_save_objects(records)
        batch.status = "completed"
        batch.records_loaded = len(records)
        batch.notes = f"Loaded {len(records)} rows"
        batch.completed_at = datetime.utcnow()
        db.session.commit()
        return {"batch": batch.to_dict(), "quality_summary": quality}
    except Exception:
        db.session.rollback()
        batch.status = "failed"
        batch.notes = "Import failed"
        batch.completed_at = datetime.utcnow()
        db.session.add(batch)
        db.session.commit()
        raise



def load_sample_data(replace_existing: bool = True):
    csv_path = current_app.config["SAMPLE_DATA_CSV"]
    df = load_dataframe_from_csv(csv_path)
    return upsert_positions_from_dataframe(df, Path(csv_path).name, replace_existing=replace_existing)



def ensure_sample_data_loaded():
    if PositionSnapshot.query.count() == 0:
        load_sample_data(replace_existing=True)



def normalize_filter_values(filters: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    filters = dict(filters or {})
    normalized = {}
    for key, value in filters.items():
        if value in (None, "", []):
            continue
        if isinstance(value, str) and "," in value and key not in {"start_date", "end_date", "as_of_date"}:
            normalized[key] = [item.strip() for item in value.split(",") if item.strip()]
        else:
            normalized[key] = value
    return normalized



def base_query(filters: Optional[Dict[str, Any]] = None):
    filters = normalize_filter_values(filters)
    query = db.session.query(PositionSnapshot)
    simple_fields = {
        "book_id": PositionSnapshot.book_id,
        "legal_entity": PositionSnapshot.legal_entity,
        "asset_class": PositionSnapshot.asset_class,
        "issuer": PositionSnapshot.issuer,
        "sector": PositionSnapshot.sector,
        "rating": PositionSnapshot.rating,
        "exchange": PositionSnapshot.exchange,
        "country": PositionSnapshot.country,
        "trade_currency": PositionSnapshot.trade_currency,
        "maturity_bucket": PositionSnapshot.maturity_bucket,
    }
    if filters.get("as_of_date"):
        parsed = parse_date(filters.get("as_of_date"))
        if not parsed:
            raise ValueError("Invalid date format for as_of_date. Use YYYY-MM-DD or a parseable date.")
        query = query.filter(PositionSnapshot.as_of_date == parsed)
    else:
        if filters.get("start_date"):
            parsed = parse_date(filters.get("start_date"))
            if not parsed:
                raise ValueError("Invalid date format for start_date.")
            query = query.filter(PositionSnapshot.as_of_date >= parsed)
        if filters.get("end_date"):
            parsed = parse_date(filters.get("end_date"))
            if not parsed:
                raise ValueError("Invalid date format for end_date.")
            query = query.filter(PositionSnapshot.as_of_date <= parsed)
    for key, column in simple_fields.items():
        value = filters.get(key)
        if not value:
            continue
        if isinstance(value, list):
            query = query.filter(column.in_(value))
        else:
            query = query.filter(column == value)
    return query



def query_scope_summary(filters: Optional[Dict[str, Any]] = None):
    query = base_query(filters)
    latest = query.with_entities(func.max(PositionSnapshot.as_of_date)).scalar()
    earliest = query.with_entities(func.min(PositionSnapshot.as_of_date)).scalar()
    return {
        "row_count": int(query.count()),
        "latest_available_date": latest.isoformat() if latest else None,
        "earliest_available_date": earliest.isoformat() if earliest else None,
        "filters": normalize_filter_values(filters),
    }



def serialize_positions(items: Iterable[PositionSnapshot]) -> List[Dict[str, Any]]:
    return [item.to_dict() for item in items]



def positions_page(filters: Optional[Dict[str, Any]] = None, page: int = 1, page_size: int = 50, sort_by: str = "as_of_date", sort_order: str = "desc"):
    query = base_query(filters)
    allowed_sort = {
        "as_of_date": PositionSnapshot.as_of_date,
        "trade_id": PositionSnapshot.trade_id,
        "book_id": PositionSnapshot.book_id,
        "asset_class": PositionSnapshot.asset_class,
        "market_value": PositionSnapshot.market_value,
        "component_var": PositionSnapshot.component_var,
    }
    order_column = allowed_sort.get(sort_by, PositionSnapshot.as_of_date)
    query = query.order_by(desc(order_column) if sort_order.lower() == "desc" else asc(order_column))
    total = query.count()
    items = query.offset((page - 1) * page_size).limit(page_size).all()
    return {
        "items": serialize_positions(items),
        "page": page,
        "page_size": page_size,
        "total": total,
        "scope": query_scope_summary(filters),
    }



def report_overview(filters: Optional[Dict[str, Any]] = None):
    query = base_query(filters)
    row = query.with_entities(
        func.count(PositionSnapshot.id),
        func.sum(PositionSnapshot.market_value),
        func.sum(func.coalesce(PositionSnapshot.market_value_var, 0.0)),
        func.sum(func.coalesce(PositionSnapshot.component_var, 0.0)),
        func.sum(func.coalesce(PositionSnapshot.delta, 0.0)),
        func.sum(func.coalesce(PositionSnapshot.cs01, 0.0)),
    ).first()
    scope = query_scope_summary(filters)
    return {
        "latest_available_date": scope["latest_available_date"],
        "trade_count": int(row[0] or 0),
        "market_value": float(row[1] or 0.0),
        "market_value_var": float(row[2] or 0.0),
        "component_var": float(row[3] or 0.0),
        "delta": float(row[4] or 0.0),
        "cs01": float(row[5] or 0.0),
        "row_count": scope["row_count"],
        "filters_applied": scope["filters"],
    }



def grouped_exposure(group_by: str, filters: Optional[Dict[str, Any]] = None):
    if group_by not in ALLOWED_GROUP_FIELDS:
        raise ValueError(f"Unsupported group_by '{group_by}'")
    group_column = getattr(PositionSnapshot, group_by)
    rows = (
        base_query(filters)
        .with_entities(
            group_column.label("group_value"),
            func.count(PositionSnapshot.id).label("trade_count"),
            func.sum(PositionSnapshot.quantity).label("quantity"),
            func.sum(PositionSnapshot.market_value).label("market_value"),
            func.sum(func.coalesce(PositionSnapshot.market_value_var, 0.0)).label("market_value_var"),
            func.sum(func.coalesce(PositionSnapshot.component_var, 0.0)).label("component_var"),
            func.sum(func.coalesce(PositionSnapshot.delta, 0.0)).label("delta"),
            func.sum(func.coalesce(PositionSnapshot.cs01, 0.0)).label("cs01"),
        )
        .group_by(group_column)
        .order_by(desc("market_value"))
        .all()
    )
    total_market_value = sum(float(row.market_value or 0.0) for row in rows)
    items = []
    for row in rows:
        mv = float(row.market_value or 0.0)
        items.append(
            {
                "group_by": group_by,
                "group_value": row.group_value or "Unspecified",
                "trade_count": int(row.trade_count or 0),
                "quantity": float(row.quantity or 0.0),
                "market_value": mv,
                "market_value_var": float(row.market_value_var or 0.0),
                "component_var": float(row.component_var or 0.0),
                "delta": float(row.delta or 0.0),
                "cs01": float(row.cs01 or 0.0),
                "pct_of_market_value": (mv / total_market_value) if total_market_value else 0.0,
            }
        )
    return {
        "group_by": group_by,
        "items": items,
        "total_market_value": total_market_value,
        "filters_applied": normalize_filter_values(filters),
    }



def var_summary(filters: Optional[Dict[str, Any]] = None):
    query = base_query(filters)
    totals = query.with_entities(
        func.count(PositionSnapshot.id),
        func.sum(func.coalesce(PositionSnapshot.market_value_var, 0.0)),
        func.avg(func.coalesce(PositionSnapshot.market_value_var, 0.0)),
        func.sum(func.coalesce(PositionSnapshot.marginal_var, 0.0)),
        func.avg(func.coalesce(PositionSnapshot.marginal_var, 0.0)),
        func.sum(func.coalesce(PositionSnapshot.component_var, 0.0)),
        func.avg(func.coalesce(PositionSnapshot.component_var, 0.0)),
        func.sum(func.coalesce(PositionSnapshot.pct_contribution, 0.0)),
    ).first()
    top = (
        query.with_entities(
            PositionSnapshot.trade_id,
            PositionSnapshot.book_id,
            PositionSnapshot.asset_class,
            PositionSnapshot.issuer,
            PositionSnapshot.market_value,
            PositionSnapshot.market_value_var,
            PositionSnapshot.marginal_var,
            PositionSnapshot.component_var,
            PositionSnapshot.pct_contribution,
        )
        .order_by(desc(func.coalesce(PositionSnapshot.component_var, 0.0)))
        .limit(10)
        .all()
    )
    return {
        "summary": {
            "trade_count": int(totals[0] or 0),
            "total_market_value_var": float(totals[1] or 0.0),
            "average_market_value_var": float(totals[2] or 0.0),
            "total_marginal_var": float(totals[3] or 0.0),
            "average_marginal_var": float(totals[4] or 0.0),
            "total_component_var": float(totals[5] or 0.0),
            "average_component_var": float(totals[6] or 0.0),
            "sum_pct_contribution": float(totals[7] or 0.0),
        },
        "top_component_var_contributors": [
            {
                "trade_id": row.trade_id,
                "book_id": row.book_id,
                "asset_class": row.asset_class,
                "issuer": row.issuer,
                "market_value": float(row.market_value or 0.0),
                "market_value_var": float(row.market_value_var or 0.0),
                "marginal_var": float(row.marginal_var or 0.0),
                "component_var": float(row.component_var or 0.0),
                "pct_contribution": float(row.pct_contribution or 0.0),
            }
            for row in top
        ],
        "filters_applied": normalize_filter_values(filters),
    }



def trend_report(metric: str, group_by: Optional[str] = None, filters: Optional[Dict[str, Any]] = None):
    if metric not in ALLOWED_TREND_METRICS:
        raise ValueError(f"Unsupported metric '{metric}'")
    metric_column = getattr(PositionSnapshot, metric)
    query = base_query(filters)
    if group_by:
        if group_by not in ALLOWED_GROUP_FIELDS:
            raise ValueError(f"Unsupported group_by '{group_by}'")
        group_column = getattr(PositionSnapshot, group_by)
        rows = (
            query.with_entities(
                PositionSnapshot.as_of_date.label("as_of_date"),
                group_column.label("group_value"),
                func.sum(func.coalesce(metric_column, 0.0)).label("metric_value"),
            )
            .group_by(PositionSnapshot.as_of_date, group_column)
            .order_by(asc(PositionSnapshot.as_of_date), asc(group_column))
            .all()
        )
        series = defaultdict(list)
        for row in rows:
            series[row.group_value or "Unspecified"].append(
                {
                    "as_of_date": row.as_of_date.isoformat() if row.as_of_date else None,
                    "value": float(row.metric_value or 0.0),
                }
            )
        return {"metric": metric, "group_by": group_by, "series": dict(series), "filters_applied": normalize_filter_values(filters)}
    rows = (
        query.with_entities(
            PositionSnapshot.as_of_date.label("as_of_date"),
            func.sum(func.coalesce(metric_column, 0.0)).label("metric_value"),
        )
        .group_by(PositionSnapshot.as_of_date)
        .order_by(asc(PositionSnapshot.as_of_date))
        .all()
    )
    return {
        "metric": metric,
        "group_by": None,
        "series": [
            {"as_of_date": row.as_of_date.isoformat() if row.as_of_date else None, "value": float(row.metric_value or 0.0)}
            for row in rows
        ],
        "filters_applied": normalize_filter_values(filters),
    }



def filter_metadata():
    fields = [
        "book_id",
        "legal_entity",
        "asset_class",
        "issuer",
        "sector",
        "rating",
        "exchange",
        "country",
        "trade_currency",
        "maturity_bucket",
    ]
    latest = db.session.query(func.max(PositionSnapshot.as_of_date)).scalar()
    earliest = db.session.query(func.min(PositionSnapshot.as_of_date)).scalar()
    result = {
        "date_range": {
            "min": earliest.isoformat() if earliest else None,
            "max": latest.isoformat() if latest else None,
        }
    }
    for field in fields:
        column = getattr(PositionSnapshot, field)
        result[field] = [
            row[0]
            for row in db.session.query(column).filter(column.isnot(None)).distinct().order_by(asc(column)).all()
        ]
    return result



def data_quality_report(filters: Optional[Dict[str, Any]] = None):
    records = base_query(filters).all()
    rows = [record.to_dict() for record in records]
    if not rows:
        return {
            "row_count": 0,
            "missing_mandatory_columns": [],
            "duplicate_date_trade_keys": 0,
            "mandatory_null_counts": {},
            "invalid_asset_class_values": [],
            "invalid_buy_sell_values": [],
        }
    df = pd.DataFrame(rows).rename(columns={"as_of_date": "date", "trade_currency": "currency_x"})
    report = dataset_quality_summary(df)
    report["filters_applied"] = normalize_filter_values(filters)
    return report



def dashboard_payload(filters: Optional[Dict[str, Any]] = None):
    return {
        "overview": report_overview(filters),
        "asset_class_exposure": grouped_exposure("asset_class", filters),
        "var_summary": var_summary(filters),
        "market_value_trend": trend_report("market_value", None, filters),
    }



def narrative_payload(filters: Optional[Dict[str, Any]] = None):
    overview = report_overview(filters)
    exposure = grouped_exposure("asset_class", filters).get("items", [])
    leader = exposure[0] if exposure else None
    bullets = [
        f"Demo analytics scope contains {overview['trade_count']} positions across {overview['row_count']} filtered rows.",
        f"Aggregate market value is {overview['market_value']:,.2f} with component VaR of {overview['component_var']:,.2f}.",
    ]
    if leader:
        bullets.append(
            f"Largest exposure bucket is {leader['group_value']} at {leader['market_value']:,.2f}, or {leader['pct_of_market_value']:.2%} of filtered market value."
        )
    return {
        "narrative": " ".join(bullets),
        "executive_summary": bullets,
        "filters_applied": normalize_filter_values(filters),
    }



def top_trades_by_market_value(filters: Optional[Dict[str, Any]] = None, limit: int = 10):
    rows = (
        base_query(filters)
        .order_by(desc(PositionSnapshot.market_value))
        .limit(limit)
        .all()
    )
    return {
        "items": [record.to_dict() for record in rows],
        "limit": limit,
        "filters_applied": normalize_filter_values(filters),
    }



def exception_trades_missing_mappings(filters: Optional[Dict[str, Any]] = None, limit: int = 100):
    rows = (
        base_query(filters)
        .filter((PositionSnapshot.isin.is_(None)) | (PositionSnapshot.issuer.is_(None)))
        .order_by(desc(PositionSnapshot.as_of_date), asc(PositionSnapshot.trade_id))
        .limit(limit)
        .all()
    )
    return {
        "items": [record.to_dict() for record in rows],
        "limit": limit,
        "filters_applied": normalize_filter_values(filters),
    }



def anomaly_high_market_value_missing_var(filters: Optional[Dict[str, Any]] = None, limit: int = 25):
    query = base_query(filters)
    threshold = query.with_entities(func.avg(PositionSnapshot.market_value)).scalar() or 0.0
    rows = (
        query.filter(
            PositionSnapshot.market_value >= threshold,
            (PositionSnapshot.market_value_var.is_(None))
            | (PositionSnapshot.marginal_var.is_(None))
            | (PositionSnapshot.component_var.is_(None))
            | (PositionSnapshot.pct_contribution.is_(None)),
        )
        .order_by(desc(PositionSnapshot.market_value))
        .limit(limit)
        .all()
    )
    return {
        "threshold_market_value": float(threshold),
        "items": [record.to_dict() for record in rows],
        "filters_applied": normalize_filter_values(filters),
    }



def compare_group_values(group_by: str, values: List[str], filters: Optional[Dict[str, Any]] = None):
    if group_by not in ALLOWED_GROUP_FIELDS:
        raise ValueError(f"Unsupported group_by '{group_by}'")
    group_column = getattr(PositionSnapshot, group_by)
    rows = (
        base_query(filters)
        .filter(group_column.in_(values))
        .with_entities(
            group_column.label("group_value"),
            func.count(PositionSnapshot.id).label("trade_count"),
            func.sum(PositionSnapshot.market_value).label("market_value"),
            func.sum(func.coalesce(PositionSnapshot.component_var, 0.0)).label("component_var"),
            func.sum(func.coalesce(PositionSnapshot.market_value_var, 0.0)).label("market_value_var"),
        )
        .group_by(group_column)
        .order_by(desc("market_value"))
        .all()
    )
    return {
        "group_by": group_by,
        "items": [
            {
                "group_value": row.group_value,
                "trade_count": int(row.trade_count or 0),
                "market_value": float(row.market_value or 0.0),
                "component_var": float(row.component_var or 0.0),
                "market_value_var": float(row.market_value_var or 0.0),
            }
            for row in rows
        ],
        "filters_applied": normalize_filter_values(filters),
    }
