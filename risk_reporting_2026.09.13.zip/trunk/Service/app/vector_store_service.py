from __future__ import annotations

import json
from dataclasses import dataclass
from threading import Lock
from typing import Any, Dict, List, Optional

import pandas as pd
from langchain_core.documents import Document
from langchain_core.tools import Tool
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from .metadata_service import load_dictionary_workbook, map_csv_to_dictionary_entities, validate_csv_against_dictionary
from .report_service import dataframe_scope_summary, dataset_quality_summary, load_dataframe_from_csv, normalize_dataframe


@dataclass
class RiskVectorStore:
    store_name: str
    documents: List[Document]
    profile_payload: Dict[str, Any]
    vectorizer: TfidfVectorizer
    matrix: Any

    def similarity_search(self, query: str, k: int = 8) -> List[Dict[str, Any]]:
        if not query or not query.strip():
            return []
        query_vector = self.vectorizer.transform([query])
        scores = cosine_similarity(query_vector, self.matrix).flatten()
        if scores.size == 0:
            return []
        top_indices = scores.argsort()[::-1][:k]
        results = []
        for idx in top_indices:
            score = float(scores[idx])
            doc = self.documents[int(idx)]
            results.append(
                {
                    "score": round(score, 6),
                    "content": doc.page_content,
                    "metadata": doc.metadata,
                }
            )
        return results

    def as_tool(self, filters: Optional[Dict[str, Any]] = None) -> Tool:
        def _search(query: str) -> str:
            payload = {
                "store_name": self.store_name,
                "filters_applied": filters or {},
                "results": self.similarity_search(query, k=8),
                "profile": {
                    "coverage": self.profile_payload.get("coverage", {}),
                    "validation": self.profile_payload.get("validation", {}),
                    "recommendation": self.profile_payload.get("recommendation", {}),
                },
            }
            return json.dumps(payload, default=str)

        return Tool(
            name="search_risk_vector_store",
            description=(
                "Search the active vector store built from uploaded risk CSV data and Excel data dictionary. "
                "Always use this tool before answering. The tool returns relevant trade rows, aggregate summaries, "
                "data-quality notes, and dictionary definitions."
            ),
            func=_search,
        )


class VectorStoreRegistry:
    def __init__(self):
        self._lock = Lock()
        self._default_store: Optional[RiskVectorStore] = None
        self._active_store: Optional[RiskVectorStore] = None

    def set_default(self, store: RiskVectorStore):
        with self._lock:
            self._default_store = store
            if self._active_store is None:
                self._active_store = store

    def set_active(self, store: RiskVectorStore):
        with self._lock:
            self._active_store = store
            if self._default_store is None:
                self._default_store = store

    def get_active(self) -> Optional[RiskVectorStore]:
        with self._lock:
            return self._active_store or self._default_store


REGISTRY = VectorStoreRegistry()


SIGNAL_COLUMNS = [
    "date",
    "trade_id",
    "book_id",
    "legal_entity",
    "instrument_id",
    "asset_class",
    "buy_sell",
    "quantity",
    "market_value",
    "currency_x",
    "delta",
    "modified_duration",
    "convexity",
    "cs01",
    "krd_1y",
    "krd_2y",
    "krd_5y",
    "krd_10y",
    "market_value_var",
    "marginal_var",
    "component_var",
    "pct_contribution",
    "isin",
    "ticker",
    "exchange",
    "country",
    "sector",
    "issuer",
    "coupon_type",
    "coupon_rate",
    "coupon_frequency",
    "maturity_date",
    "day_count",
    "seniority",
    "rating",
]


AGGREGATION_DIMENSIONS = ["book_id", "legal_entity", "asset_class", "sector", "issuer", "rating", "exchange", "country"]


def _compact_row_payload(row: pd.Series) -> Dict[str, Any]:
    payload = {}
    for column in SIGNAL_COLUMNS:
        if column not in row.index:
            continue
        value = row[column]
        if pd.isna(value):
            continue
        payload[column] = value.isoformat() if hasattr(value, "isoformat") else value
    return payload



def _row_to_text(payload: Dict[str, Any]) -> str:
    parts = [f"{key}: {value}" for key, value in payload.items()]
    return "Trade snapshot | " + " | ".join(parts)



def _aggregate_frame(df: pd.DataFrame, group_by: List[str]) -> List[Document]:
    available_group_by = [column for column in group_by if column in df.columns]
    if not available_group_by:
        return []
    metrics = {"quantity": "sum", "market_value": "sum"}
    for column in ["market_value_var", "marginal_var", "component_var", "pct_contribution", "delta", "cs01"]:
        if column in df.columns:
            metrics[column] = "sum"
    grouped = df.groupby(available_group_by, dropna=False).agg(metrics).reset_index()
    documents = []
    for _, row in grouped.iterrows():
        payload = _compact_row_payload(row)
        text = "Exposure concentration risk aggregate summary | " + " | ".join([f"{key}: {value}" for key, value in payload.items()])
        documents.append(
            Document(
                page_content=text,
                metadata={
                    "doc_type": "aggregate_summary",
                    "group_by": available_group_by,
                    "columns_used": list(payload.keys()),
                    "payload": payload,
                },
            )
        )
    return documents



def _top_trade_documents(df: pd.DataFrame, limit: int = 50) -> List[Document]:
    if "market_value" not in df.columns:
        return []
    top_df = df.sort_values("market_value", ascending=False).head(limit)
    documents = []
    for _, row in top_df.iterrows():
        payload = _compact_row_payload(row)
        documents.append(
            Document(
                page_content="Top risk contributor trade snapshot | " + " | ".join([f"{key}: {value}" for key, value in payload.items()]),
                metadata={
                    "doc_type": "top_trade",
                    "columns_used": list(payload.keys()),
                    "payload": payload,
                },
            )
        )
    return documents



def _exception_documents(df: pd.DataFrame) -> List[Document]:
    documents: List[Document] = []
    for column in ["market_value_var", "marginal_var", "component_var", "pct_contribution"]:
        if column not in df.columns:
            continue
    if {"market_value", "trade_id"}.issubset(df.columns):
        average_market_value = float(pd.to_numeric(df["market_value"], errors="coerce").mean())
        exception_mask = pd.to_numeric(df["market_value"], errors="coerce") >= average_market_value
        for risk_column in ["market_value_var", "marginal_var", "component_var", "pct_contribution"]:
            if risk_column in df.columns:
                exception_mask = exception_mask & df[risk_column].isna()
        exception_rows = df[exception_mask].head(100)
        for _, row in exception_rows.iterrows():
            payload = _compact_row_payload(row)
            documents.append(
                Document(
                    page_content="Risk exception trade with missing VaR fields and incomplete attribution | " + " | ".join([f"{key}: {value}" for key, value in payload.items()]),
                    metadata={
                        "doc_type": "exception_trade",
                        "columns_used": list(payload.keys()),
                        "payload": payload,
                    },
                )
            )
    return documents



def _dictionary_documents(workbook_dict: Dict[str, List[dict]]) -> List[Document]:
    documents: List[Document] = []
    for sheet_name, rows in workbook_dict.items():
        sheet_text = " ; ".join(
            [
                f"Attribute {row.get('Attribute')}, Data Type {row.get('Data Type')}, Description {row.get('Description')}, Regulatory Criticality {row.get('Regulatory Criticality')}"
                for row in rows
            ]
        )
        documents.append(
            Document(
                page_content=f"Risk reporting data dictionary sheet {sheet_name} | {sheet_text}",
                metadata={
                    "doc_type": "dictionary_sheet",
                    "sheet_name": sheet_name,
                    "columns_used": ["Attribute", "Data Type", "Description", "Regulatory Criticality"],
                    "payload": rows[:20],
                },
            )
        )
        for row in rows:
            payload = {
                "sheet_name": sheet_name,
                "attribute": row.get("Attribute"),
                "data_type": row.get("Data Type"),
                "description": row.get("Description"),
                "regulatory_criticality": row.get("Regulatory Criticality"),
                "risk_impact": row.get("Risk Impact"),
            }
            documents.append(
                Document(
                    page_content="Risk reporting dictionary attribute definition | " + " | ".join([f"{key}: {value}" for key, value in payload.items() if value]),
                    metadata={
                        "doc_type": "dictionary_attribute",
                        "columns_used": list(payload.keys()),
                        "payload": payload,
                    },
                )
            )
    return documents



def _profile_document(profile_payload: Dict[str, Any]) -> Document:
    coverage = profile_payload.get("coverage", {})
    validation = profile_payload.get("validation", {})
    recommendation = profile_payload.get("recommendation", {})
    text = (
        f"Risk reporting dataset profile and readiness summary | coverage: {json.dumps(coverage, default=str)} | "
        f"validation: {json.dumps(validation, default=str)} | recommendation: {json.dumps(recommendation, default=str)}"
    )
    return Document(
        page_content=text,
        metadata={
            "doc_type": "dataset_profile",
            "columns_used": ["coverage", "validation", "recommendation"],
            "payload": profile_payload,
        },
    )



def _build_documents(csv_df: pd.DataFrame, workbook_dict: Dict[str, List[dict]], profile_payload: Dict[str, Any]) -> List[Document]:
    normalized_df = normalize_dataframe(csv_df)
    documents: List[Document] = [_profile_document(profile_payload)]
    documents.extend(_dictionary_documents(workbook_dict))
    documents.extend(_aggregate_frame(normalized_df, ["date", "book_id"]))
    for dimension in AGGREGATION_DIMENSIONS:
        if dimension in normalized_df.columns:
            documents.extend(_aggregate_frame(normalized_df, [dimension]))
            if "date" in normalized_df.columns:
                documents.extend(_aggregate_frame(normalized_df, ["date", dimension]))
    documents.extend(_top_trade_documents(normalized_df, limit=100))
    documents.extend(_exception_documents(normalized_df))
    for _, row in normalized_df.iterrows():
        payload = _compact_row_payload(row)
        documents.append(
            Document(
                page_content="Risk trade snapshot record | " + _row_to_text(payload),
                metadata={
                    "doc_type": "trade_snapshot",
                    "columns_used": list(payload.keys()),
                    "payload": payload,
                },
            )
        )
    return documents



def _profile_payload(csv_df: pd.DataFrame, workbook_dict: Dict[str, List[dict]], csv_name: str, excel_name: str) -> Dict[str, Any]:
    scope = dataframe_scope_summary(csv_df)
    validation = validate_csv_against_dictionary(csv_df, workbook_dict)
    mapping = map_csv_to_dictionary_entities(csv_df.columns, workbook_dict)
    quality = dataset_quality_summary(csv_df)
    safe_analyses = [
        "Exposure rollups",
        "Trade blotter summaries",
        "Historical trends" if "date" in csv_df.columns else "Trend analysis requires date column",
        "VaR contribution analysis" if all(col in csv_df.columns for col in ["market_value_var", "marginal_var", "component_var", "pct_contribution"]) else "Exposure and sensitivity analysis",
    ]
    risky = []
    if validation.get("missing_mandatory_columns"):
        risky.append("Mandatory columns are missing, so some analytics may be incomplete.")
    if quality.get("duplicate_date_trade_keys"):
        risky.append("Duplicate date-trade keys were found and can distort rollups.")
    return {
        "files": {"csv_file": csv_name, "excel_file": excel_name},
        "coverage": scope,
        "dictionary": {"sheets": list(workbook_dict.keys())},
        "entity_mapping": mapping,
        "validation": validation,
        "recommendation": {
            "safe_analyses": safe_analyses,
            "risky_analyses": risky,
            "next_steps": [
                "Use /api/v1/assistant/chat to query the active vector store.",
                "Start with exposure, exception, or VaR driver questions.",
                "Repair missing mandatory fields before relying on detailed attribution.",
            ],
        },
    }



def build_vector_store_from_sources(csv_source: Any, excel_source: Any, store_name: str) -> RiskVectorStore:
    csv_df = load_dataframe_from_csv(csv_source)
    workbook_dict = load_dictionary_workbook(excel_source)
    csv_name = getattr(csv_source, "filename", None) or str(csv_source).split("/")[-1]
    excel_name = getattr(excel_source, "filename", None) or str(excel_source).split("/")[-1]
    profile_payload = _profile_payload(csv_df, workbook_dict, csv_name, excel_name)
    documents = _build_documents(csv_df, workbook_dict, profile_payload)
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2), max_features=50000)
    matrix = vectorizer.fit_transform([doc.page_content for doc in documents])
    return RiskVectorStore(
        store_name=store_name,
        documents=documents,
        profile_payload=profile_payload,
        vectorizer=vectorizer,
        matrix=matrix,
    )



def ensure_default_vector_store(csv_path: str, excel_path: str) -> RiskVectorStore:
    existing = REGISTRY.get_active()
    if existing is not None:
        return existing
    store = build_vector_store_from_sources(csv_path, excel_path, store_name="default_sample_store")
    REGISTRY.set_default(store)
    return store



def activate_uploaded_vector_store(csv_source: Any, excel_source: Any, store_name: str = "uploaded_store") -> RiskVectorStore:
    store = build_vector_store_from_sources(csv_source, excel_source, store_name=store_name)
    REGISTRY.set_active(store)
    return store



def get_active_vector_store() -> Optional[RiskVectorStore]:
    return REGISTRY.get_active()
