from __future__ import annotations

from typing import Dict, Iterable, List

import pandas as pd


SHEET_ENTITY_ORDER = [
    "Trade_Position",
    "Instrument_Reference",
    "Market_Data",
    "Risk_Sensitivities",
    "Covariance_Correlation",
    "VaR_Parameters",
]

ATTRIBUTE_ALIASES = {
    "currency": ["currency", "currency_x", "trade_currency"],
    "reporting_currency": ["currency_y", "reporting_currency"],
    "key_rate_duration": ["key_rate_duration", "krd_1y", "krd_2y", "krd_5y", "krd_10y"],
    "return": ["return", "returns"],
}

MANDATORY_EXPECTED = [
    "trade_id",
    "book_id",
    "legal_entity",
    "instrument_id",
    "asset_class",
    "quantity",
    "market_value",
    "currency",
    "trading_book_flag",
]


def load_dictionary_workbook(xlsx_path: str) -> Dict[str, List[dict]]:
    workbook = pd.ExcelFile(xlsx_path)
    result: Dict[str, List[dict]] = {}
    for sheet in workbook.sheet_names:
        frame = pd.read_excel(xlsx_path, sheet_name=sheet)
        frame.columns = [str(c).strip() for c in frame.columns]
        result[sheet] = frame.fillna("").to_dict(orient="records")
    return result


def canonical_to_matches(attribute: str) -> List[str]:
    return [attribute] + ATTRIBUTE_ALIASES.get(attribute, [])


def column_exists(csv_columns: Iterable[str], attribute: str) -> bool:
    lower_columns = {str(col).strip().lower() for col in csv_columns}
    for candidate in canonical_to_matches(attribute):
        if candidate.lower() in lower_columns:
            return True
    if attribute == "key_rate_duration":
        return all(key.lower() in lower_columns for key in ["krd_1y", "krd_2y", "krd_5y", "krd_10y"])
    return False


def matched_columns(csv_columns: Iterable[str], attribute: str) -> List[str]:
    columns = [str(col).strip() for col in csv_columns]
    lower_map = {col.lower(): col for col in columns}
    matches = []
    for candidate in canonical_to_matches(attribute):
        if candidate.lower() in lower_map:
            matches.append(lower_map[candidate.lower()])
    if attribute == "key_rate_duration":
        for candidate in ["krd_1y", "krd_2y", "krd_5y", "krd_10y"]:
            if candidate.lower() in lower_map:
                matches.append(lower_map[candidate.lower()])
    return sorted(set(matches))


def dictionary_summary(xlsx_path: str) -> Dict[str, object]:
    workbook_dict = load_dictionary_workbook(xlsx_path)
    summary = {
        "sheets": list(workbook_dict.keys()),
        "sheet_details": {},
        "mandatory_fields": MANDATORY_EXPECTED,
    }
    for sheet, rows in workbook_dict.items():
        summary["sheet_details"][sheet] = {
            "attributes": [row.get("Attribute") for row in rows],
            "row_count": len(rows),
        }
    return summary


def map_csv_to_dictionary_entities(csv_columns: Iterable[str], workbook_dict: Dict[str, List[dict]]) -> Dict[str, List[dict]]:
    mapping: Dict[str, List[dict]] = {}
    for sheet in SHEET_ENTITY_ORDER:
        rows = workbook_dict.get(sheet, [])
        sheet_matches = []
        for row in rows:
            attribute = str(row.get("Attribute", "")).strip()
            if not attribute:
                continue
            matches = matched_columns(csv_columns, attribute)
            if matches:
                sheet_matches.append(
                    {
                        "attribute": attribute,
                        "matched_columns": matches,
                        "criticality": row.get("Regulatory Criticality", ""),
                        "data_type": row.get("Data Type", ""),
                    }
                )
        mapping[sheet] = sheet_matches
    return mapping


def validate_csv_against_dictionary(csv_frame: pd.DataFrame, workbook_dict: Dict[str, List[dict]]) -> Dict[str, object]:
    csv_columns = list(csv_frame.columns)
    missing_mandatory = [field for field in MANDATORY_EXPECTED if not column_exists(csv_columns, field)]
    null_rates = {
        col: round(float(csv_frame[col].isna().mean()), 4)
        for col in csv_columns
    }

    empty_critical_fields = {}
    for field in MANDATORY_EXPECTED:
        for matched in matched_columns(csv_columns, field):
            empty_critical_fields[matched] = int(csv_frame[matched].isna().sum())

    type_mismatches = {}
    numeric_candidates = [
        "quantity",
        "market_value",
        "delta",
        "modified_duration",
        "convexity",
        "cs01",
        "market_value_var",
        "marginal_var",
        "component_var",
        "pct_contribution",
    ]
    for column in numeric_candidates:
        if column in csv_frame.columns:
            coerced = pd.to_numeric(csv_frame[column], errors="coerce")
            mismatch_count = int(coerced.isna().sum() - csv_frame[column].isna().sum())
            if mismatch_count > 0:
                type_mismatches[column] = mismatch_count

    conditional_notes = []
    for sheet, rows in workbook_dict.items():
        for row in rows:
            if str(row.get("Regulatory Criticality", "")).strip().lower() != "conditional":
                continue
            attribute = str(row.get("Attribute", "")).strip()
            if not attribute:
                continue
            matches = matched_columns(csv_columns, attribute)
            if not matches:
                conditional_notes.append(
                    {
                        "attribute": attribute,
                        "status": "not_present",
                        "note": "Conditional field not present; may be acceptable depending on asset class.",
                    }
                )
                continue
            if all(int(csv_frame[col].isna().sum()) == len(csv_frame) for col in matches):
                conditional_notes.append(
                    {
                        "attribute": attribute,
                        "status": "empty",
                        "note": "Conditional field exists but is empty for the uploaded dataset.",
                    }
                )

    return {
        "missing_mandatory_columns": missing_mandatory,
        "null_rates": null_rates,
        "empty_critical_fields": empty_critical_fields,
        "type_mismatches": type_mismatches,
        "conditional_field_notes": conditional_notes,
    }
