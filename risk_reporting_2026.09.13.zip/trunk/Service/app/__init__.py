from flask import Flask, jsonify

from .config import Config
from .extensions import cors, db
from .routes import api



def create_app(config_object=Config):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_object)

    db.init_app(app)
    cors.init_app(app, resources={r"/api/*": {"origins": "*"}})
    app.register_blueprint(api)

    @app.errorhandler(400)
    def bad_request(error):
        return jsonify({"error": str(error)}), 400

    @app.errorhandler(404)
    def not_found(_error):
        return jsonify({"error": "Resource not found."}), 404

    @app.errorhandler(413)
    def too_large(_error):
        return jsonify({"error": "Uploaded file exceeds size limit."}), 413

    @app.errorhandler(ValueError)
    def value_error(error):
        return jsonify({"error": str(error)}), 400

    with app.app_context():
        db.create_all()

    return app
