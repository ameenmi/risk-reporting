from __future__ import annotations

import json
import os
import re
from datetime import datetime
from typing import Any, Dict, List, Optional
import traceback
from flask import current_app
from langchain_core.messages import AIMessage, HumanMessage
import pandas as pd

from .extensions import db
from .models import ChatMessage, ChatSession
from .vector_store_service import (
    activate_uploaded_vector_store,
    ensure_default_vector_store,
    get_active_vector_store,
)


SUGGESTED_QUERIES = [
    "Upload CSV and profile the dataset",
    "Generate a one-page Market Risk snapshot by book and sector",
    "Show top 5 contributors to component VaR and explain why",
    "Find trades with missing ISIN or issuer mapping and list them",
    "Run an exception report: missing mandatory fields per trade",
    "Explain today’s VaR drivers in plain language for leadership",
    "Create a narrative: BAU summary + ad-hoc deep dive for TRD_EQBD_01",
]


class AssistantError(ValueError):
    def __init__(self, error_type: str, message: str, impact: str, fix_options: List[str], fallback: str):
        super().__init__(message)
        self.error_type = error_type
        self.message = message
        self.impact = impact
        self.fix_options = fix_options
        self.fallback = fallback

    def to_response(self, filters: Optional[Dict[str, Any]] = None):
        return {
            "title": "Request could not be fully computed",
            "answer_type": "error",
            "executive_summary": [
                f"Error type: {self.error_type}.",
                self.message,
                f"Impact: {self.impact}",
            ],
            "key_findings": [],
            "exceptions_and_data_quality": [self.message],
            "recommended_next_actions": self.fix_options + [self.fallback],
            "filters_applied": filters or {},
            "columns_used": [],
            "data_scope": {},
            "table": None,
            "narrative": self.message,
            "source_notice": "Demo analytics from sample data; not production risk advice.",
        }



def ensure_assistant_ready():
    store = get_active_vector_store()
    if store is not None:
        return store
    return ensure_default_vector_store(
        current_app.config["SAMPLE_DATA_CSV"],
        current_app.config["SAMPLE_DICTIONARY_XLSX"],
    )



def create_session(title: Optional[str] = None):
    session = ChatSession(title=title or "New Risk Chat")
    db.session.add(session)
    db.session.commit()
    return session



def list_sessions():
    return [session.to_dict() for session in ChatSession.query.order_by(ChatSession.updated_at.desc()).all()]



def get_session_or_create(session_id: Optional[int], title_from_message: Optional[str] = None):
    if session_id:
        session = ChatSession.query.get(session_id)
        if not session:
            raise AssistantError(
                "Invalid session id",
                f"No chat session found for id {session_id}.",
                "Conversation history cannot be attached to the request.",
                ["Create a new session", "Pass a valid existing session_id"],
                "Retry the request without session_id to start a fresh chat.",
            )
        return session
    return create_session((title_from_message or "New Risk Chat")[:255])



def add_message(session: ChatSession, role: str, content: str, response_json: Optional[Dict[str, Any]] = None):
    message = ChatMessage(
        session_id=session.id,
        role=role,
        content=content,
        response_json=json.dumps(response_json, default=str) if response_json else None,
    )
    session.updated_at = datetime.utcnow()
    db.session.add(message)
    db.session.add(session)
    db.session.commit()
    return message



def get_session_messages(session_id: int):
    session = ChatSession.query.get(session_id)
    if not session:
        raise AssistantError(
            "Invalid session id",
            f"No chat session found for id {session_id}.",
            "Stored history cannot be returned.",
            ["Provide a valid session_id", "Create a new session first"],
            "Start a new chat session and ask the question again.",
        )
    return {
        "session": session.to_dict(),
        "messages": [message.to_dict() for message in session.messages],
    }



def _normalize_user_filters(filters: Optional[Dict[str, Any]] = None):
    normalized = dict(filters or {})
    for key, value in list(normalized.items()):
        if value in (None, "", []):
            normalized.pop(key, None)
    return normalized



def _query_with_filters(message: str, filters: Dict[str, Any]) -> str:
    if not filters:
        return message
    filter_text = ", ".join([f"{key}={value}" for key, value in filters.items()])
    return f"{message}. Apply these filters if relevant: {filter_text}."



def _message_history_for_agent(session: ChatSession):
    history = []
    for message in session.messages[-8:]:
        if message.role == "user":
            history.append(HumanMessage(content=message.content))
        elif message.role == "assistant":
            history.append(AIMessage(content=message.content))
    return history



def _json_only(text: str) -> Optional[Dict[str, Any]]:
    if not text:
        return None
    cleaned = text.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```(?:json)?\s*", "", cleaned)
        cleaned = re.sub(r"\s*```$", "", cleaned)
    try:
        return json.loads(cleaned)
    except Exception:
        match = re.search(r"\{.*\}", cleaned, re.S)
        if match:
            try:
                return json.loads(match.group(0))
            except Exception:
                return None
    return None



def _langchain_brief(payload: Dict[str, Any]) -> Optional[str]:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return None
    try:
        from langchain_core.prompts import ChatPromptTemplate
        from langchain_openai import ChatOpenAI

        prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    "You are Risk Reporting Copilot. Convert structured analytics into a concise executive briefing. "
                    "Do not invent numbers. Keep it demo-safe and explicitly mention when insights are based on sample data.",
                ),
                (
                    "human",
                    "Use this JSON payload to draft a short executive narrative with three parts: summary, risks, next steps.\n{payload}",
                ),
            ]
        )
        llm = ChatOpenAI(model=current_app.config["OPENAI_MODEL"], temperature=0.2)
        response = (prompt | llm).invoke({"payload": json.dumps(payload, default=str)})
        return response.content
    except Exception:
        return None



def _default_data_scope(store, filters: Dict[str, Any]) -> Dict[str, Any]:
    coverage = store.profile_payload.get("coverage", {})
    return {
        "row_count": coverage.get("row_count"),
        "latest_available_date": coverage.get("date_range", {}).get("max"),
        "earliest_available_date": coverage.get("date_range", {}).get("min"),
        "filters": filters,
        "vector_store": store.store_name,
        "files": store.profile_payload.get("files", {}),
    }



def _build_response_payload(
    *,
    title: str,
    answer_type: str,
    executive_summary: List[str],
    key_findings: List[Any],
    exceptions_and_data_quality: List[str],
    recommended_next_actions: List[str],
    filters_applied: Dict[str, Any],
    columns_used: List[str],
    data_scope: Dict[str, Any],
    table: Optional[Dict[str, Any]],
):
    payload = {
        "title": title,
        "answer_type": answer_type,
        "executive_summary": executive_summary,
        "key_findings": key_findings,
        "exceptions_and_data_quality": exceptions_and_data_quality,
        "recommended_next_actions": recommended_next_actions,
        "filters_applied": filters_applied,
        "columns_used": columns_used,
        "data_scope": data_scope,
        "table": table,
        "source_notice": "Demo analytics from sample data; do not treat as regulatory advice or production-ready risk output.",
    }
    payload["narrative"] = _langchain_brief(payload) or " ".join(executive_summary)
    return payload



def _result_matches_filters(result: Dict[str, Any], filters: Dict[str, Any]) -> bool:
    if not filters:
        return True
    payload = result.get("metadata", {}).get("payload", {}) or {}
    if not isinstance(payload, dict):
        return True
    for key, value in filters.items():
        if key in {"start_date", "end_date", "as_of_date"}:
            record_date = payload.get("date") or payload.get("as_of_date")
            if not record_date:
                continue
            try:
                record_date = pd.to_datetime(record_date).date()
            except Exception:
                continue
            if key == "as_of_date" and record_date.isoformat() != str(value):
                return False
            if key == "start_date" and record_date < pd.to_datetime(value).date():
                return False
            if key == "end_date" and record_date > pd.to_datetime(value).date():
                return False
            continue
        payload_value = payload.get(key)
        if payload_value is None:
            continue
        if isinstance(value, list):
            if str(payload_value) not in [str(item) for item in value]:
                return False
        else:
            if str(payload_value) != str(value):
                return False
    return True



def _fallback_answer(message: str, store, filters: Dict[str, Any]):
    query_text = _query_with_filters(message, filters)
    retrieved = store.similarity_search(query_text, k=12)
    filtered_results = [item for item in retrieved if _result_matches_filters(item, filters)]
    results = filtered_results or retrieved
    if not results:
        raise AssistantError(
            "No matching context found",
            "The vector store did not return any relevant records for the question.",
            "The assistant cannot safely ground an answer in the active CSV/Excel content.",
            ["Rephrase the question with a clearer business concept", "Upload or profile the intended files first"],
            "Ask for a data readiness summary or a broad exposure overview.",
        )

    columns_used = sorted(
        {
            column
            for result in results[:8]
            for column in result.get("metadata", {}).get("columns_used", [])
        }
    )
    table_rows = []
    for result in results[:10]:
        payload = result.get("metadata", {}).get("payload")
        if isinstance(payload, dict):
            table_rows.append(payload)

    key_findings = []
    for result in results[:6]:
        payload = result.get("metadata", {}).get("payload")
        if isinstance(payload, dict):
            key_findings.append(payload)
        else:
            key_findings.append(
                {
                    "doc_type": result.get("metadata", {}).get("doc_type"),
                    "snippet": result.get("content", "")[:500],
                    "score": result.get("score"),
                }
            )

    profile_validation = store.profile_payload.get("validation", {})
    exceptions = []
    missing_mandatory = profile_validation.get("missing_mandatory_columns", [])
    if missing_mandatory:
        exceptions.append(
            f"Missing mandatory columns detected in the active dataset: {', '.join(missing_mandatory)}."
        )
    conditional_notes = profile_validation.get("conditional_field_notes", [])
    if conditional_notes:
        exceptions.append(
            f"Conditional field notes were identified for {len(conditional_notes)} attributes; some analytics may be partial by asset class."
        )
    if not exceptions:
        exceptions.append("No blocking data-quality issue was surfaced in the retrieved evidence, but outputs remain demo analytics from sample data.")

    first_result = results[0]
    first_payload = first_result.get("metadata", {}).get("payload", {}) or {}
    if not isinstance(first_payload, dict):
        first_payload = {}
    executive_summary = [
        f"Answer grounded in the active vector store '{store.store_name}' built from {store.profile_payload.get('files', {}).get('csv_file')} and {store.profile_payload.get('files', {}).get('excel_file')}." ,
        f"Top retrieved evidence type was {first_result.get('metadata', {}).get('doc_type', 'retrieved_context')} with similarity score {first_result.get('score', 0):.3f}.",
        f"Dataset coverage available to the assistant is {store.profile_payload.get('coverage', {}).get('row_count')} rows spanning {store.profile_payload.get('coverage', {}).get('date_range', {}).get('min')} to {store.profile_payload.get('coverage', {}).get('date_range', {}).get('max')}." ,
    ]
    if first_payload:
        executive_summary.append(
            "Most relevant structured evidence references " + ", ".join([f"{key}={value}" for key, value in list(first_payload.items())[:4]]) + "."
        )

    answer_type = first_result.get("metadata", {}).get("doc_type", "analysis")
    if answer_type in {"trade_snapshot", "aggregate_summary", "top_trade"}:
        answer_type = "analysis"
    elif answer_type == "dataset_profile":
        answer_type = "profile"
    elif answer_type == "exception_trade":
        answer_type = "exceptions"
    elif answer_type.startswith("dictionary"):
        answer_type = "metadata"

    recommended_next_actions = [
        "Ask a follow-up question with explicit filters if you want a narrower answer.",
        "Use the file profiling flow to refresh the active vector store with newly uploaded files.",
        "Ask for exposure, VaR driver, anomaly, or reference-data clarification based on the same dataset.",
    ]

    return _build_response_payload(
        title="Risk Reporting Copilot answer",
        answer_type=answer_type,
        executive_summary=executive_summary,
        key_findings=key_findings,
        exceptions_and_data_quality=exceptions,
        recommended_next_actions=recommended_next_actions,
        filters_applied=filters,
        columns_used=columns_used,
        data_scope=_default_data_scope(store, filters),
        table={"type": "retrieval_results", "rows": table_rows} if table_rows else None,
    )



def _agent_answer(message: str, session: ChatSession, store, filters: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    api_key = current_app.config["AZURE_OPENAI_API_KEY"]
    print("inside _langchain_brief - api key - length - " + str(len(str(api_key))))
    if not api_key:
        return None
    try:
        from langchain_classic.agents import AgentExecutor, create_tool_calling_agent
        #from langchain.agents import AgentExecutor, create_tool_calling_agent
        from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
        #from langchain_openai import ChatOpenAI
        from langchain_openai import AzureChatOpenAI

        tool = store.as_tool(filters=filters)
        prompt = ChatPromptTemplate.from_messages(
            [
                (
                    "system",
                    "You are Risk Reporting Copilot. You must answer only from the active vector store tool. "
                    "Before answering, search the tool at least once. Do not invent metrics. Treat all outputs as demo analytics from sample data. "
                    "Return ONLY valid JSON with keys: title, answer_type, executive_summary, key_findings, exceptions_and_data_quality, "
                    "recommended_next_actions, filters_applied, columns_used, data_scope, table, narrative, source_notice. "
                    "executive_summary, key_findings, exceptions_and_data_quality, recommended_next_actions, and columns_used must be arrays. "
                    "filters_applied and data_scope must be objects. table must be either null or an object with type and rows. always include in the table object the data referred for analysis."
                    "If evidence is weak, say so explicitly in exceptions_and_data_quality."
                ),
                MessagesPlaceholder("chat_history"),
                (
                    "human",
                    "User question: {input}\nFilters: {filters_json}\nUse the tool to ground the answer. Keep the response concise and audit-friendly.",
                ),
                MessagesPlaceholder("agent_scratchpad"),
            ]
        )
        #llm = ChatOpenAI(model=current_app.config["OPENAI_MODEL"], temperature=0.1)
        llm = AzureChatOpenAI(azure_endpoint = current_app.config["AZURE_OPENAI_ENDPOINT"],
                            openai_api_key = current_app.config["AZURE_OPENAI_API_KEY"],
                            openai_api_version = current_app.config["OPENAI_API_VERSION"],
                            deployment_name = current_app.config["OPENAI_MODEL"],
                            model= current_app.config["OPENAI_MODEL"])
        print("created LLM reference")
        agent = create_tool_calling_agent(llm, [tool], prompt)
        executor = AgentExecutor(agent=agent, tools=[tool], verbose=False)
        print("Created agent executor")
        result = executor.invoke(
            {
                "input": message,
                "filters_json": json.dumps(filters, default=str),
                "chat_history": _message_history_for_agent(session),
            }
        )
        print("Executed agent call. Response - " + str(result))
        parsed = _json_only(result.get("output", ""))
        if not parsed:
            print("Parsed output could not be generated. Returning None")
            return None
        parsed.setdefault("title", "Risk Reporting Copilot answer")
        parsed.setdefault("answer_type", "analysis")
        parsed.setdefault("executive_summary", [])
        parsed.setdefault("key_findings", [])
        parsed.setdefault("exceptions_and_data_quality", [])
        parsed.setdefault("recommended_next_actions", [])
        parsed.setdefault("filters_applied", filters)
        parsed.setdefault("columns_used", [])
        parsed.setdefault("data_scope", _default_data_scope(store, filters))
        parsed.setdefault("table", None)
        parsed.setdefault("source_notice", "Demo analytics from sample data; do not treat as regulatory advice or production-ready risk output.")
        parsed.setdefault("narrative", " ".join(parsed.get("executive_summary", [])))
        return parsed
    except Exception as ex:        
        print("Exception in openai call ")
        print(ex)
        traceback.print_exc()
        return None



def profile_uploaded_files(csv_file=None, excel_file=None):
    csv_source = csv_file or current_app.config["SAMPLE_DATA_CSV"]
    excel_source = excel_file or current_app.config["SAMPLE_DICTIONARY_XLSX"]
    store = activate_uploaded_vector_store(csv_source, excel_source, store_name="uploaded_profile_store")
    return store.profile_payload



def answer_chat(message: str, session_id: Optional[int] = None, filters: Optional[Dict[str, Any]] = None):
    if not message or not message.strip():
        raise AssistantError(
            "Missing question",
            "The assistant needs a non-empty message to analyze.",
            "No BAU or ad-hoc analytics can be generated.",
            ["Send a natural language question", "Or choose one of the suggested prompts"],
            "Ask for a data readiness summary or exposure overview.",
        )

    store = ensure_assistant_ready()
    filters = _normalize_user_filters(filters)
    session = get_session_or_create(session_id, message)
    add_message(session, "user", message)

    try:
        reply = _agent_answer(message, session, store, filters) or _fallback_answer(message, store, filters)
    except AssistantError as exc:
        reply = exc.to_response(filters)
    except Exception as exc:
        reply = AssistantError(
            "Assistant processing error",
            str(exc),
            "The assistant could not complete a grounded vector-store search answer for the request.",
            ["Retry the question", "Re-profile the files to refresh the vector store"],
            "Ask a broader question such as exposure overview or data readiness summary.",
        ).to_response(filters)

    assistant_message = add_message(session, "assistant", reply.get("narrative", reply["title"]), reply)
    return {
        "session": session.to_dict(),
        "assistant_message_id": assistant_message.id,
        "reply": reply,
    }
