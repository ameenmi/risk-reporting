import json

from flask import Blueprint, current_app, jsonify, request

from .assistant_service import (
    SUGGESTED_QUERIES,
    answer_chat,
    create_session,
    get_session_messages,
    list_sessions,
    profile_uploaded_files,
)
from .extensions import db
from .metadata_service import dictionary_summary
from .models import AuditLog, ImportBatch
from .report_service import (
    dashboard_payload,
    data_quality_report,
    ensure_sample_data_loaded,
    filter_metadata,
    grouped_exposure,
    load_dataframe_from_csv,
    load_sample_data,
    narrative_payload,
    positions_page,
    report_overview,
    trend_report,
    upsert_positions_from_dataframe,
    var_summary,
)


api = Blueprint("api", __name__, url_prefix="/api/v1")


FILTER_FIELDS = [
    "as_of_date",
    "start_date",
    "end_date",
    "book_id",
    "legal_entity",
    "asset_class",
    "issuer",
    "sector",
    "rating",
    "exchange",
    "country",
    "trade_currency",
    "maturity_bucket",
]


def _filters_from_request():
    filters = {}
    for field in FILTER_FIELDS:
        value = request.args.get(field)
        if value not in (None, ""):
            filters[field] = value
    return filters



def _pagination(default_page_size=50, max_page_size=500):
    page = max(int(request.args.get("page", 1)), 1)
    page_size = min(max(int(request.args.get("page_size", default_page_size)), 1), max_page_size)
    return page, page_size



def _log_event(event_type: str, details: dict):
    entry = AuditLog(
        event_type=event_type,
        endpoint=request.path,
        actor=request.headers.get("X-Actor", "system"),
        details=json.dumps(details, default=str),
    )
    db.session.add(entry)
    db.session.commit()
    return entry


@api.before_app_request
def initialize_sample_data():
    ensure_sample_data_loaded()


@api.get("/health")
def health_check():
    return jsonify(
        {
            "status": "ok",
            "service": "risk-reporting-backend",
            "database": current_app.config["SQLALCHEMY_DATABASE_URI"],
        }
    )


@api.get("/meta/data-dictionary")
def data_dictionary():
    payload = dictionary_summary(current_app.config["SAMPLE_DICTIONARY_XLSX"])
    _log_event("metadata_view", {"resource": "data_dictionary"})
    return jsonify(payload)


@api.get("/meta/filters")
def available_filters():
    payload = filter_metadata()
    _log_event("metadata_view", {"resource": "filters"})
    return jsonify(payload)


@api.get("/assistant/suggestions")
def assistant_suggestions():
    payload = {"suggested_queries": SUGGESTED_QUERIES}
    _log_event("assistant_metadata", payload)
    return jsonify(payload)


@api.post("/assistant/intake/profile")
def assistant_profile_upload():
    csv_file = request.files.get("csv_file")
    excel_file = request.files.get("excel_file")
    payload = profile_uploaded_files(csv_file=csv_file, excel_file=excel_file)
    _log_event("assistant_profile", {"csv_file": payload['files']['csv_file'], "excel_file": payload['files']['excel_file']})
    return jsonify(payload)


@api.post("/assistant/sessions")
def assistant_create_session():
    body = request.get_json(silent=True) or {}
    session = create_session(body.get("title"))
    _log_event("assistant_session_create", session.to_dict())
    return jsonify(session.to_dict()), 201


@api.get("/assistant/sessions")
def assistant_sessions():
    payload = {"items": list_sessions()}
    _log_event("assistant_session_list", {"count": len(payload['items'])})
    return jsonify(payload)


@api.get("/assistant/sessions/<int:session_id>/messages")
def assistant_session_messages(session_id: int):
    payload = get_session_messages(session_id)
    _log_event("assistant_history", {"session_id": session_id})
    return jsonify(payload)


@api.post("/assistant/chat")
def assistant_chat():
    body = request.get_json(silent=True) or {}
    payload = answer_chat(
        message=body.get("message", ""),
        session_id=body.get("session_id"),
        filters=body.get("filters") or {},
    )
    _log_event("assistant_chat", {"session_id": payload['session']['id'], "title": payload['reply']['title']})
    return jsonify(payload)


@api.get("/imports")
def imports_list():
    items = ImportBatch.query.order_by(ImportBatch.started_at.desc()).limit(50).all()
    return jsonify({"items": [item.to_dict() for item in items]})


@api.post("/imports/sample-data")
def import_sample_data():
    body = request.get_json(silent=True) or {}
    payload = load_sample_data(replace_existing=bool(body.get("replace_existing", True)))
    _log_event("data_import", {"mode": "sample", **payload["batch"]})
    return jsonify(payload), 201


@api.post("/imports/upload")
def import_uploaded_csv():
    if "file" not in request.files:
        return jsonify({"error": "Missing file in multipart form data."}), 400
    uploaded_file = request.files["file"]
    if not uploaded_file.filename.lower().endswith(".csv"):
        return jsonify({"error": "Only CSV uploads are supported."}), 400
    replace_existing = str(request.form.get("replace_existing", "true")).lower() in {"true", "1", "yes", "y"}
    df = load_dataframe_from_csv(uploaded_file)
    payload = upsert_positions_from_dataframe(df, uploaded_file.filename, replace_existing=replace_existing)
    _log_event("data_import", {"mode": "upload", **payload["batch"]})
    return jsonify(payload), 201


@api.get("/positions")
def positions():
    page, page_size = _pagination()
    payload = positions_page(
        filters=_filters_from_request(),
        page=page,
        page_size=page_size,
        sort_by=request.args.get("sort_by", "as_of_date"),
        sort_order=request.args.get("sort_order", "desc"),
    )
    _log_event("report_run", {"report": "positions", "page": page, "page_size": page_size})
    return jsonify(payload)


@api.get("/reports/dashboard")
def dashboard():
    payload = dashboard_payload(_filters_from_request())
    _log_event("report_run", {"report": "dashboard"})
    return jsonify(payload)


@api.get("/reports/trade-blotter")
def trade_blotter():
    page, page_size = _pagination(default_page_size=100)
    payload = positions_page(
        filters=_filters_from_request(),
        page=page,
        page_size=page_size,
        sort_by=request.args.get("sort_by", "market_value"),
        sort_order=request.args.get("sort_order", "desc"),
    )
    _log_event("report_run", {"report": "trade_blotter"})
    return jsonify(payload)


@api.get("/reports/position-summary")
def position_summary():
    payload = report_overview(_filters_from_request())
    _log_event("report_run", {"report": "position_summary"})
    return jsonify(payload)


@api.get("/reports/exposure")
def exposure():
    group_by = request.args.get("group_by", "asset_class")
    payload = grouped_exposure(group_by, _filters_from_request())
    _log_event("report_run", {"report": "exposure", "group_by": group_by})
    return jsonify(payload)


@api.get("/reports/var-summary")
def report_var_summary():
    payload = var_summary(_filters_from_request())
    _log_event("report_run", {"report": "var_summary"})
    return jsonify(payload)


@api.get("/reports/var-contribution")
def report_var_contribution():
    group_by = request.args.get("group_by", "issuer")
    payload = grouped_exposure(group_by, _filters_from_request())
    _log_event("report_run", {"report": "var_contribution", "group_by": group_by})
    return jsonify(payload)


@api.get("/reports/trends")
def report_trends():
    payload = trend_report(
        metric=request.args.get("metric", "market_value"),
        group_by=request.args.get("group_by"),
        filters=_filters_from_request(),
    )
    _log_event("report_run", {"report": "trends", "metric": request.args.get('metric', 'market_value')})
    return jsonify(payload)


@api.get("/reports/data-quality")
def report_data_quality():
    payload = data_quality_report(_filters_from_request())
    _log_event("report_run", {"report": "data_quality"})
    return jsonify(payload)


@api.get("/analytics/narrative")
def analytics_narrative():
    payload = narrative_payload(_filters_from_request())
    _log_event("report_run", {"report": "narrative"})
    return jsonify(payload)


@api.get("/audit-logs")
def audit_logs():
    page, page_size = _pagination(default_page_size=50)
    query = AuditLog.query.order_by(AuditLog.created_at.desc())
    total = query.count()
    items = query.offset((page - 1) * page_size).limit(page_size).all()
    return jsonify(
        {
            "items": [item.to_dict() for item in items],
            "page": page,
            "page_size": page_size,
            "total": total,
        }
    )
