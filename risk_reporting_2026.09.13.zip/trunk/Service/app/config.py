import os
from pathlib import Path
import configparser

BASE_DIR = Path(__file__).resolve().parent.parent
INSTANCE_DIR = BASE_DIR / "instance"
INSTANCE_DIR.mkdir(parents=True, exist_ok=True)

config = configparser.ConfigParser()

config.read(BASE_DIR / "config.ini")

class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "risk-reporting-demo-secret")
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "DATABASE_URL",
        f"sqlite:///{INSTANCE_DIR / 'risk_reporting.db'}",
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JSON_SORT_KEYS = False
    MAX_CONTENT_LENGTH = 100 * 1024 * 1024

    SAMPLE_DATA_CSV = str(BASE_DIR / "sample_data" / "VaR_Sample_Data_Set.csv")
    SAMPLE_DICTIONARY_XLSX = str(BASE_DIR / "sample_data" / "Trading_Book_VaR_Data_Dictionary.xlsx")
    CHATBOT_REQUIREMENTS_TXT = str(BASE_DIR / "sample_data" / "Chatbot_Service_Requirement.txt")

    #OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
    OPENAI_MODEL = config["AppConfig"]["OPENAI_MODEL"]
    AZURE_OPENAI_ENDPOINT = config["AppConfig"]["AZURE_OPENAI_ENDPOINT"]
    AZURE_OPENAI_API_KEY = config["AppConfig"]["AZURE_OPENAI_API_KEY"]
    OPENAI_API_VERSION = config["AppConfig"]["OPENAI_API_VERSION"]
