from datetime import datetime

from .extensions import db


class PositionSnapshot(db.Model):
    __tablename__ = "position_snapshots"

    id = db.Column(db.Integer, primary_key=True)
    as_of_date = db.Column(db.Date, nullable=False, index=True)
    trade_id = db.Column(db.String(128), nullable=False)
    book_id = db.Column(db.String(64), nullable=False, index=True)
    legal_entity = db.Column(db.String(64), nullable=False, index=True)
    instrument_id = db.Column(db.String(64), nullable=False, index=True)
    asset_class = db.Column(db.String(32), nullable=False, index=True)
    buy_sell = db.Column(db.String(16), nullable=False)
    quantity = db.Column(db.Float, nullable=False)
    market_value = db.Column(db.Float, nullable=False)
    trade_currency = db.Column(db.String(16), nullable=False, index=True)
    reporting_currency = db.Column(db.String(16), nullable=True)
    trading_book_flag = db.Column(db.Boolean, nullable=False, default=True)
    delta = db.Column(db.Float, nullable=True)
    modified_duration = db.Column(db.Float, nullable=True)
    convexity = db.Column(db.Float, nullable=True)
    cs01 = db.Column(db.Float, nullable=True)
    krd_1y = db.Column(db.Float, nullable=True)
    krd_2y = db.Column(db.Float, nullable=True)
    krd_5y = db.Column(db.Float, nullable=True)
    krd_10y = db.Column(db.Float, nullable=True)
    fx_delta = db.Column(db.Float, nullable=True)
    market_value_var = db.Column(db.Float, nullable=True)
    marginal_var = db.Column(db.Float, nullable=True)
    component_var = db.Column(db.Float, nullable=True)
    pct_contribution = db.Column(db.Float, nullable=True)
    isin = db.Column(db.String(32), nullable=True, index=True)
    ticker = db.Column(db.String(32), nullable=True, index=True)
    exchange = db.Column(db.String(32), nullable=True)
    country = db.Column(db.String(8), nullable=True)
    sector = db.Column(db.String(64), nullable=True, index=True)
    issuer = db.Column(db.String(128), nullable=True, index=True)
    corporate_actions_flag = db.Column(db.Boolean, nullable=True)
    coupon_type = db.Column(db.String(32), nullable=True)
    coupon_rate = db.Column(db.Float, nullable=True)
    coupon_frequency = db.Column(db.String(32), nullable=True)
    maturity_date = db.Column(db.Date, nullable=True, index=True)
    day_count = db.Column(db.String(32), nullable=True)
    embedded_option = db.Column(db.Boolean, nullable=True)
    seniority = db.Column(db.String(64), nullable=True)
    rating = db.Column(db.String(32), nullable=True, index=True)
    maturity_bucket = db.Column(db.String(32), nullable=True, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)

    __table_args__ = (
        db.UniqueConstraint("as_of_date", "trade_id", name="uq_position_date_trade"),
        db.Index("idx_position_scope", "as_of_date", "book_id", "asset_class", "issuer"),
    )

    def to_dict(self):
        return {
            "id": self.id,
            "as_of_date": self.as_of_date.isoformat() if self.as_of_date else None,
            "trade_id": self.trade_id,
            "book_id": self.book_id,
            "legal_entity": self.legal_entity,
            "instrument_id": self.instrument_id,
            "asset_class": self.asset_class,
            "buy_sell": self.buy_sell,
            "quantity": self.quantity,
            "market_value": self.market_value,
            "trade_currency": self.trade_currency,
            "reporting_currency": self.reporting_currency,
            "trading_book_flag": self.trading_book_flag,
            "delta": self.delta,
            "modified_duration": self.modified_duration,
            "convexity": self.convexity,
            "cs01": self.cs01,
            "krd_1y": self.krd_1y,
            "krd_2y": self.krd_2y,
            "krd_5y": self.krd_5y,
            "krd_10y": self.krd_10y,
            "fx_delta": self.fx_delta,
            "market_value_var": self.market_value_var,
            "marginal_var": self.marginal_var,
            "component_var": self.component_var,
            "pct_contribution": self.pct_contribution,
            "isin": self.isin,
            "ticker": self.ticker,
            "exchange": self.exchange,
            "country": self.country,
            "sector": self.sector,
            "issuer": self.issuer,
            "corporate_actions_flag": self.corporate_actions_flag,
            "coupon_type": self.coupon_type,
            "coupon_rate": self.coupon_rate,
            "coupon_frequency": self.coupon_frequency,
            "maturity_date": self.maturity_date.isoformat() if self.maturity_date else None,
            "day_count": self.day_count,
            "embedded_option": self.embedded_option,
            "seniority": self.seniority,
            "rating": self.rating,
            "maturity_bucket": self.maturity_bucket,
        }


class ImportBatch(db.Model):
    __tablename__ = "import_batches"

    id = db.Column(db.Integer, primary_key=True)
    filename = db.Column(db.String(255), nullable=False)
    status = db.Column(db.String(32), nullable=False, default="pending")
    records_loaded = db.Column(db.Integer, nullable=False, default=0)
    replace_existing = db.Column(db.Boolean, nullable=False, default=True)
    notes = db.Column(db.Text, nullable=True)
    started_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    completed_at = db.Column(db.DateTime, nullable=True)

    def to_dict(self):
        return {
            "id": self.id,
            "filename": self.filename,
            "status": self.status,
            "records_loaded": self.records_loaded,
            "replace_existing": self.replace_existing,
            "notes": self.notes,
            "started_at": self.started_at.isoformat() if self.started_at else None,
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
        }


class AuditLog(db.Model):
    __tablename__ = "audit_logs"

    id = db.Column(db.Integer, primary_key=True)
    event_type = db.Column(db.String(64), nullable=False, index=True)
    endpoint = db.Column(db.String(255), nullable=True)
    actor = db.Column(db.String(128), nullable=True, default="system")
    details = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)

    def to_dict(self):
        return {
            "id": self.id,
            "event_type": self.event_type,
            "endpoint": self.endpoint,
            "actor": self.actor,
            "details": self.details,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }


class ChatSession(db.Model):
    __tablename__ = "chat_sessions"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(255), nullable=False, default="New Risk Chat")
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)

    messages = db.relationship(
        "ChatMessage",
        backref="session",
        lazy=True,
        cascade="all, delete-orphan",
        order_by="ChatMessage.created_at.asc()",
    )

    def to_dict(self):
        return {
            "id": self.id,
            "title": self.title,
            "created_at": self.created_at.isoformat() if self.created_at else None,
            "updated_at": self.updated_at.isoformat() if self.updated_at else None,
        }


class ChatMessage(db.Model):
    __tablename__ = "chat_messages"

    id = db.Column(db.Integer, primary_key=True)
    session_id = db.Column(db.Integer, db.ForeignKey("chat_sessions.id"), nullable=False, index=True)
    role = db.Column(db.String(16), nullable=False)
    content = db.Column(db.Text, nullable=False)
    response_json = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, nullable=False, index=True)

    def to_dict(self):
        return {
            "id": self.id,
            "session_id": self.session_id,
            "role": self.role,
            "content": self.content,
            "response_json": self.response_json,
            "created_at": self.created_at.isoformat() if self.created_at else None,
        }
