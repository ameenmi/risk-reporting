from flask import Blueprint, current_app, jsonify, request

from .models import AuditLog, ImportBatch, PositionSnapshot
from .services import (
    dashboard_payload,
    data_quality_report,
    filter_metadata,
    grouped_exposure,
    load_dataframe_from_csv,
    load_sample_data,
    narrative_payload,
    positions_list,
    report_overview,
    trend_report,
    upsert_positions_from_dataframe,
    var_summary,
)
from .utils import load_json_file, pagination_params, write_audit_log


api = Blueprint("api", __name__, url_prefix="/api/v1")


@api.get("/health")
def health_check():
    payload = {
        "status": "ok",
        "service": "risk-reporting-backend",
        "database": current_app.config["SQLALCHEMY_DATABASE_URI"].split(":///")[-1],
    }
    return jsonify(payload)


@api.get("/meta/data-dictionary")
def data_dictionary():
    payload = {
        "data_dictionary": load_json_file(current_app.config["DATA_DICTIONARY_PATH"]),
        "var_parameters_reference": load_json_file(current_app.config["VAR_PARAMETERS_PATH"]),
    }
    write_audit_log("metadata_view", request.path, {"resource": "data_dictionary"})
    return jsonify(payload)


@api.get("/meta/filters")
def filters():
    payload = filter_metadata()
    write_audit_log("metadata_view", request.path, {"resource": "filters"})
    return jsonify(payload)


@api.get("/imports")
def imports_list():
    items = ImportBatch.query.order_by(ImportBatch.started_at.desc()).limit(50).all()
    return jsonify({"items": [item.to_dict() for item in items]})


@api.post("/imports/sample-data")
def import_sample_data():
    replace_existing = bool(request.json.get("replace_existing", True)) if request.is_json else True
    result = load_sample_data(replace_existing=replace_existing)
    write_audit_log("data_import", request.path, {"mode": "sample", **result["batch"]})
    return jsonify(result), 201


@api.post("/imports/upload")
def upload_positions_csv():
    if "file" not in request.files:
        return jsonify({"error": "Missing file in multipart form data."}), 400

    uploaded_file = request.files["file"]
    if not uploaded_file.filename.lower().endswith(".csv"):
        return jsonify({"error": "Only CSV uploads are supported."}), 400

    replace_existing_raw = request.form.get("replace_existing", "true")
    replace_existing = str(replace_existing_raw).lower() in {"true", "1", "yes", "y"}

    df = load_dataframe_from_csv(uploaded_file)
    result = upsert_positions_from_dataframe(df, filename=uploaded_file.filename, replace_existing=replace_existing)
    write_audit_log("data_import", request.path, {"mode": "upload", **result["batch"]})
    return jsonify(result), 201


@api.get("/positions")
def positions():
    page, page_size = pagination_params()
    payload = positions_list(page, page_size)
    write_audit_log("report_run", request.path, {"page": page, "page_size": page_size})
    return jsonify(payload)


@api.get("/reports/dashboard")
def dashboard():
    payload = dashboard_payload()
    write_audit_log("report_run", request.path, {"report": "dashboard"})
    return jsonify(payload)


@api.get("/reports/trade-blotter")
def trade_blotter():
    page, page_size = pagination_params(default_page_size=100)
    payload = positions_list(page, page_size)
    write_audit_log("report_run", request.path, {"report": "trade_blotter", "page": page, "page_size": page_size})
    return jsonify(payload)


@api.get("/reports/position-summary")
def position_summary():
    payload = report_overview()
    write_audit_log("report_run", request.path, {"report": "position_summary"})
    return jsonify(payload)


@api.get("/reports/exposure")
def exposure_report():
    group_by = request.args.get("group_by", "asset_class")
    try:
        payload = grouped_exposure(group_by)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    write_audit_log("report_run", request.path, {"report": "exposure", "group_by": group_by})
    return jsonify(payload)


@api.get("/reports/var-summary")
def var_report():
    payload = var_summary()
    write_audit_log("report_run", request.path, {"report": "var_summary"})
    return jsonify(payload)


@api.get("/reports/var-contribution")
def var_contribution_report():
    group_by = request.args.get("group_by", "issuer")
    try:
        payload = grouped_exposure(group_by)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    write_audit_log("report_run", request.path, {"report": "var_contribution", "group_by": group_by})
    return jsonify(payload)


@api.get("/reports/trends")
def trends_report():
    metric = request.args.get("metric", "market_value")
    group_by = request.args.get("group_by")
    try:
        payload = trend_report(metric, group_by)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400
    write_audit_log("report_run", request.path, {"report": "trends", "metric": metric, "group_by": group_by})
    return jsonify(payload)


@api.get("/reports/data-quality")
def quality_report():
    payload = data_quality_report()
    write_audit_log("report_run", request.path, {"report": "data_quality"})
    return jsonify(payload)


@api.route("/analytics/narrative", methods=["GET", "POST"])
def narrative_report():
    payload = narrative_payload()
    write_audit_log("report_run", request.path, {"report": "narrative"})
    return jsonify(payload)


@api.get("/audit-logs")
def audit_logs():
    page, page_size = pagination_params(default_page_size=50)
    query = AuditLog.query.order_by(AuditLog.created_at.desc())
    total = query.count()
    items = query.offset((page - 1) * page_size).limit(page_size).all()
    return jsonify(
        {
            "items": [item.to_dict() for item in items],
            "page": page,
            "page_size": page_size,
            "total": total,
        }
    )
