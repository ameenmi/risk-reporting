from __future__ import annotations

from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import pandas as pd
from flask import current_app
from sqlalchemy import asc, desc, func

from .extensions import db
from .models import ImportBatch, PositionSnapshot
from .utils import (
    ALLOWED_GROUP_FIELDS,
    ALLOWED_TREND_METRICS,
    apply_common_filters,
    dataframe_quality_summary,
    derive_maturity_bucket,
    parse_bool,
    parse_date,
)


CSV_TO_MODEL_MAP = {
    "date": "as_of_date",
    "trade_id": "trade_id",
    "book_id": "book_id",
    "legal_entity": "legal_entity",
    "instrument_id": "instrument_id",
    "asset_class": "asset_class",
    "buy_sell": "buy_sell",
    "quantity": "quantity",
    "market_value": "market_value",
    "currency_x": "trade_currency",
    "currency_y": "reporting_currency",
    "trading_book_flag": "trading_book_flag",
    "delta": "delta",
    "modified_duration": "modified_duration",
    "convexity": "convexity",
    "cs01": "cs01",
    "krd_1y": "krd_1y",
    "krd_2y": "krd_2y",
    "krd_5y": "krd_5y",
    "krd_10y": "krd_10y",
    "fx_delta": "fx_delta",
    "market_value_var": "market_value_var",
    "marginal_var": "marginal_var",
    "component_var": "component_var",
    "pct_contribution": "pct_contribution",
    "isin": "isin",
    "ticker": "ticker",
    "exchange": "exchange",
    "country": "country",
    "sector": "sector",
    "issuer": "issuer",
    "corporate_actions_flag": "corporate_actions_flag",
    "coupon_type": "coupon_type",
    "coupon_rate": "coupon_rate",
    "coupon_frequency": "coupon_frequency",
    "maturity_date": "maturity_date",
    "day_count": "day_count",
    "embedded_option": "embedded_option",
    "seniority": "seniority",
    "rating": "rating",
}


REPORT_METRICS = {
    "trade_count": func.count(PositionSnapshot.id),
    "quantity": func.sum(PositionSnapshot.quantity),
    "market_value": func.sum(PositionSnapshot.market_value),
    "market_value_var": func.sum(func.coalesce(PositionSnapshot.market_value_var, 0.0)),
    "component_var": func.sum(func.coalesce(PositionSnapshot.component_var, 0.0)),
    "delta": func.sum(func.coalesce(PositionSnapshot.delta, 0.0)),
    "cs01": func.sum(func.coalesce(PositionSnapshot.cs01, 0.0)),
}


NUMERIC_COLUMNS = [
    "quantity",
    "market_value",
    "delta",
    "modified_duration",
    "convexity",
    "cs01",
    "krd_1y",
    "krd_2y",
    "krd_5y",
    "krd_10y",
    "fx_delta",
    "market_value_var",
    "marginal_var",
    "component_var",
    "pct_contribution",
    "coupon_rate",
]


BOOLEAN_COLUMNS = ["trading_book_flag", "corporate_actions_flag", "embedded_option"]


DATE_COLUMNS = ["date", "maturity_date"]



def load_dataframe_from_csv(path_or_buffer) -> pd.DataFrame:
    df = pd.read_csv(path_or_buffer)
    df.columns = [str(col).strip() for col in df.columns]
    return df



def normalize_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    for col in NUMERIC_COLUMNS:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    for col in BOOLEAN_COLUMNS:
        if col in df.columns:
            df[col] = df[col].apply(parse_bool)
    for col in DATE_COLUMNS:
        if col in df.columns:
            df[col] = df[col].apply(parse_date)
    text_columns = [
        c
        for c in df.columns
        if c not in NUMERIC_COLUMNS and c not in BOOLEAN_COLUMNS and c not in DATE_COLUMNS
    ]
    for col in text_columns:
        df[col] = df[col].where(df[col].notna(), None)
    df["maturity_bucket"] = df.apply(
        lambda row: derive_maturity_bucket(row.get("date"), row.get("maturity_date")),
        axis=1,
    )
    return df



def upsert_positions_from_dataframe(
    df: pd.DataFrame,
    filename: str,
    replace_existing: bool = True,
) -> Dict[str, Any]:
    df = normalize_dataframe(df)
    quality = dataframe_quality_summary(df)

    batch = ImportBatch(filename=filename, status="processing", replace_existing=replace_existing)
    db.session.add(batch)
    db.session.commit()

    try:
        if replace_existing and "date" in df.columns:
            unique_dates = sorted({d for d in df["date"].dropna().tolist()})
            if unique_dates:
                db.session.query(PositionSnapshot).filter(PositionSnapshot.as_of_date.in_(unique_dates)).delete(
                    synchronize_session=False
                )
                db.session.commit()

        records: List[PositionSnapshot] = []
        for row in df.to_dict(orient="records"):
            payload = {model_key: row.get(csv_key) for csv_key, model_key in CSV_TO_MODEL_MAP.items() if csv_key in row}
            payload["maturity_bucket"] = row.get("maturity_bucket", "N/A")
            records.append(PositionSnapshot(**payload))

        db.session.bulk_save_objects(records)
        batch.status = "completed"
        batch.records_loaded = len(records)
        batch.notes = f"Loaded {len(records)} rows."
        batch.completed_at = datetime.utcnow()
        db.session.commit()
        return {
            "batch": batch.to_dict(),
            "quality_summary": quality,
        }
    except Exception as exc:
        db.session.rollback()
        batch.status = "failed"
        batch.notes = str(exc)
        batch.completed_at = datetime.utcnow()
        db.session.add(batch)
        db.session.commit()
        raise



def load_sample_data(replace_existing: bool = True) -> Dict[str, Any]:
    sample_path = current_app.config["SAMPLE_DATA_PATH"]
    df = load_dataframe_from_csv(sample_path)
    return upsert_positions_from_dataframe(df, filename=Path(sample_path).name, replace_existing=replace_existing)



def base_query():
    query = db.session.query(PositionSnapshot)
    return apply_common_filters(query, PositionSnapshot)



def latest_date_for_query(query) -> Optional[str]:
    latest = query.with_entities(func.max(PositionSnapshot.as_of_date)).scalar()
    return latest.isoformat() if latest else None



def positions_list(page: int, page_size: int) -> Dict[str, Any]:
    query = base_query()
    sort_by = request_arg("sort_by", "as_of_date")
    sort_order = request_arg("sort_order", "desc")
    allowed_sort = {
        "as_of_date": PositionSnapshot.as_of_date,
        "trade_id": PositionSnapshot.trade_id,
        "book_id": PositionSnapshot.book_id,
        "asset_class": PositionSnapshot.asset_class,
        "market_value": PositionSnapshot.market_value,
        "component_var": PositionSnapshot.component_var,
    }
    order_col = allowed_sort.get(sort_by, PositionSnapshot.as_of_date)
    query = query.order_by(desc(order_col) if sort_order.lower() == "desc" else asc(order_col))

    total = query.count()
    items = query.offset((page - 1) * page_size).limit(page_size).all()
    return {
        "items": [item.to_dict() for item in items],
        "page": page,
        "page_size": page_size,
        "total": total,
        "latest_available_date": latest_date_for_query(base_query()),
    }



def request_arg(name: str, default: Optional[str] = None) -> Optional[str]:
    from flask import request

    return request.args.get(name, default)



def report_overview() -> Dict[str, Any]:
    query = base_query()
    total_rows = query.count()
    latest_date = latest_date_for_query(query)
    agg = query.with_entities(
        func.count(PositionSnapshot.id),
        func.sum(PositionSnapshot.market_value),
        func.sum(func.coalesce(PositionSnapshot.market_value_var, 0.0)),
        func.sum(func.coalesce(PositionSnapshot.component_var, 0.0)),
        func.sum(func.coalesce(PositionSnapshot.delta, 0.0)),
        func.sum(func.coalesce(PositionSnapshot.cs01, 0.0)),
    ).first()
    return {
        "latest_available_date": latest_date,
        "trade_count": int(agg[0] or 0),
        "market_value": float(agg[1] or 0),
        "market_value_var": float(agg[2] or 0),
        "component_var": float(agg[3] or 0),
        "delta": float(agg[4] or 0),
        "cs01": float(agg[5] or 0),
        "row_count": total_rows,
    }



def grouped_exposure(group_by: str) -> Dict[str, Any]:
    if group_by not in ALLOWED_GROUP_FIELDS:
        raise ValueError(f"Unsupported group_by '{group_by}'.")
    group_col = getattr(PositionSnapshot, group_by)
    query = base_query().with_entities(
        group_col.label("group_value"),
        func.count(PositionSnapshot.id).label("trade_count"),
        func.sum(PositionSnapshot.quantity).label("quantity"),
        func.sum(PositionSnapshot.market_value).label("market_value"),
        func.sum(func.coalesce(PositionSnapshot.market_value_var, 0.0)).label("market_value_var"),
        func.sum(func.coalesce(PositionSnapshot.component_var, 0.0)).label("component_var"),
        func.sum(func.coalesce(PositionSnapshot.delta, 0.0)).label("delta"),
        func.sum(func.coalesce(PositionSnapshot.cs01, 0.0)).label("cs01"),
    ).group_by(group_col).order_by(desc("market_value"))

    rows = []
    grand_total = 0.0
    raw_rows = query.all()
    for row in raw_rows:
        grand_total += float(row.market_value or 0.0)
    for row in raw_rows:
        mv = float(row.market_value or 0.0)
        rows.append(
            {
                "group_by": group_by,
                "group_value": row.group_value or "Unspecified",
                "trade_count": int(row.trade_count or 0),
                "quantity": float(row.quantity or 0.0),
                "market_value": mv,
                "market_value_var": float(row.market_value_var or 0.0),
                "component_var": float(row.component_var or 0.0),
                "delta": float(row.delta or 0.0),
                "cs01": float(row.cs01 or 0.0),
                "pct_of_market_value": (mv / grand_total) if grand_total else 0.0,
            }
        )
    return {"group_by": group_by, "items": rows, "total_market_value": grand_total}



def var_summary() -> Dict[str, Any]:
    query = base_query()
    totals = query.with_entities(
        func.count(PositionSnapshot.id),
        func.sum(func.coalesce(PositionSnapshot.market_value_var, 0.0)),
        func.avg(func.coalesce(PositionSnapshot.market_value_var, 0.0)),
        func.sum(func.coalesce(PositionSnapshot.marginal_var, 0.0)),
        func.avg(func.coalesce(PositionSnapshot.marginal_var, 0.0)),
        func.sum(func.coalesce(PositionSnapshot.component_var, 0.0)),
        func.avg(func.coalesce(PositionSnapshot.component_var, 0.0)),
        func.sum(func.coalesce(PositionSnapshot.pct_contribution, 0.0)),
    ).first()

    top_contributors = (
        query.with_entities(
            PositionSnapshot.trade_id,
            PositionSnapshot.book_id,
            PositionSnapshot.asset_class,
            PositionSnapshot.issuer,
            PositionSnapshot.market_value,
            PositionSnapshot.market_value_var,
            PositionSnapshot.marginal_var,
            PositionSnapshot.component_var,
            PositionSnapshot.pct_contribution,
        )
        .order_by(desc(func.coalesce(PositionSnapshot.component_var, 0.0)))
        .limit(10)
        .all()
    )

    return {
        "summary": {
            "trade_count": int(totals[0] or 0),
            "total_market_value_var": float(totals[1] or 0.0),
            "average_market_value_var": float(totals[2] or 0.0),
            "total_marginal_var": float(totals[3] or 0.0),
            "average_marginal_var": float(totals[4] or 0.0),
            "total_component_var": float(totals[5] or 0.0),
            "average_component_var": float(totals[6] or 0.0),
            "sum_pct_contribution": float(totals[7] or 0.0),
        },
        "top_component_var_contributors": [
            {
                "trade_id": row.trade_id,
                "book_id": row.book_id,
                "asset_class": row.asset_class,
                "issuer": row.issuer,
                "market_value": float(row.market_value or 0.0),
                "market_value_var": float(row.market_value_var or 0.0),
                "marginal_var": float(row.marginal_var or 0.0),
                "component_var": float(row.component_var or 0.0),
                "pct_contribution": float(row.pct_contribution or 0.0),
            }
            for row in top_contributors
        ],
    }



def trend_report(metric: str, group_by: Optional[str] = None) -> Dict[str, Any]:
    if metric not in ALLOWED_TREND_METRICS:
        raise ValueError(f"Unsupported metric '{metric}'.")
    metric_col = getattr(PositionSnapshot, metric)

    if group_by and group_by not in ALLOWED_GROUP_FIELDS:
        raise ValueError(f"Unsupported group_by '{group_by}'.")

    if group_by:
        group_col = getattr(PositionSnapshot, group_by)
        rows = (
            base_query()
            .with_entities(
                PositionSnapshot.as_of_date.label("as_of_date"),
                group_col.label("group_value"),
                func.sum(func.coalesce(metric_col, 0.0)).label("metric_value"),
            )
            .group_by(PositionSnapshot.as_of_date, group_col)
            .order_by(asc(PositionSnapshot.as_of_date), asc(group_col))
            .all()
        )
        series = defaultdict(list)
        for row in rows:
            series[row.group_value or "Unspecified"].append(
                {
                    "as_of_date": row.as_of_date.isoformat() if row.as_of_date else None,
                    "value": float(row.metric_value or 0.0),
                }
            )
        return {"metric": metric, "group_by": group_by, "series": dict(series)}

    rows = (
        base_query()
        .with_entities(
            PositionSnapshot.as_of_date.label("as_of_date"),
            func.sum(func.coalesce(metric_col, 0.0)).label("metric_value"),
        )
        .group_by(PositionSnapshot.as_of_date)
        .order_by(asc(PositionSnapshot.as_of_date))
        .all()
    )
    return {
        "metric": metric,
        "group_by": None,
        "series": [
            {"as_of_date": row.as_of_date.isoformat() if row.as_of_date else None, "value": float(row.metric_value or 0.0)}
            for row in rows
        ],
    }



def filter_metadata() -> Dict[str, Any]:
    latest = db.session.query(func.max(PositionSnapshot.as_of_date)).scalar()
    earliest = db.session.query(func.min(PositionSnapshot.as_of_date)).scalar()
    fields = [
        "book_id",
        "legal_entity",
        "asset_class",
        "issuer",
        "sector",
        "rating",
        "exchange",
        "country",
        "trade_currency",
        "maturity_bucket",
    ]
    result = {
        "date_range": {
            "min": earliest.isoformat() if earliest else None,
            "max": latest.isoformat() if latest else None,
        }
    }
    for field in fields:
        column = getattr(PositionSnapshot, field)
        values = [
            row[0]
            for row in db.session.query(column)
            .filter(column.isnot(None))
            .distinct()
            .order_by(asc(column))
            .all()
        ]
        result[field] = values
    return result



def data_quality_report() -> Dict[str, Any]:
    query = base_query()
    records = query.all()
    rows = [item.to_dict() for item in records]
    if not rows:
        return {
            "row_count": 0,
            "missing_mandatory_columns": [],
            "duplicate_date_trade_keys": 0,
            "mandatory_null_counts": {},
            "invalid_asset_class_values": [],
            "invalid_buy_sell_values": [],
        }
    df = pd.DataFrame(rows)
    df = df.rename(columns={"as_of_date": "date"})
    if "trade_currency" in df.columns:
        df["currency_x"] = df["trade_currency"]
    return dataframe_quality_summary(df)



def dashboard_payload() -> Dict[str, Any]:
    overview = report_overview()
    exposures = grouped_exposure("asset_class")
    var_details = var_summary()
    trend = trend_report("market_value")
    return {
        "overview": overview,
        "asset_class_exposure": exposures,
        "var_summary": var_details,
        "market_value_trend": trend,
    }



def narrative_payload() -> Dict[str, Any]:
    overview = report_overview()
    exposure = grouped_exposure("asset_class").get("items", [])
    largest = exposure[0] if exposure else None
    latest_date = overview.get("latest_available_date")
    text_parts = [
        f"As of {latest_date}, the platform contains {overview['trade_count']} trade snapshots in scope.",
        f"Total market value is {overview['market_value']:,.2f} and aggregated component VaR is {overview['component_var']:,.2f}.",
    ]
    if largest:
        text_parts.append(
            f"The largest exposure bucket is {largest['group_value']} with market value {largest['market_value']:,.2f}, representing {largest['pct_of_market_value']:.2%} of the filtered portfolio."
        )
    if overview.get("cs01"):
        text_parts.append(f"Aggregate CS01 stands at {overview['cs01']:,.2f} and can be used for credit spread sensitivity monitoring.")
    return {
        "narrative": " ".join(text_parts),
        "overview": overview,
    }
