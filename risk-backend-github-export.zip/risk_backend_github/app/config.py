import os
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent.parent
INSTANCE_DIR = BASE_DIR / "instance"
INSTANCE_DIR.mkdir(parents=True, exist_ok=True)


class Config:
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-secret-key")
    SQLALCHEMY_DATABASE_URI = os.getenv(
        "DATABASE_URL",
        f"sqlite:///{INSTANCE_DIR / 'risk_reporting.db'}",
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    JSON_SORT_KEYS = False
    MAX_CONTENT_LENGTH = 50 * 1024 * 1024
    SAMPLE_DATA_PATH = str(BASE_DIR / "sample_data" / "VaR_Sample_Data_Set.csv")
    DATA_DICTIONARY_PATH = str(BASE_DIR / "app" / "seed_data" / "data_dictionary.json")
    VAR_PARAMETERS_PATH = str(BASE_DIR / "app" / "seed_data" / "var_parameters.json")
