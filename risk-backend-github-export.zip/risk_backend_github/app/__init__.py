from flask import Flask, jsonify

from .config import Config
from .extensions import cors, db
from .routes import api



def create_app(config_object=Config):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(config_object)

    db.init_app(app)
    cors.init_app(app, resources={r"/api/*": {"origins": "*"}})

    app.register_blueprint(api)

    @app.errorhandler(404)
    def not_found(_error):
        return jsonify({"error": "Resource not found."}), 404

    @app.errorhandler(413)
    def request_too_large(_error):
        return jsonify({"error": "Uploaded file exceeds size limit."}), 413

    @app.cli.command("init-db")
    def init_db_command():
        db.create_all()
        print("Database initialized.")

    @app.cli.command("seed-sample-data")
    def seed_sample_data_command():
        from .services import load_sample_data

        db.create_all()
        result = load_sample_data(replace_existing=True)
        print(f"Loaded {result['batch']['records_loaded']} records into SQLite.")

    with app.app_context():
        db.create_all()

    return app
