import json
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import pandas as pd
from flask import request

from .extensions import db
from .models import AuditLog


MANDATORY_COLUMNS = {
    "date",
    "trade_id",
    "book_id",
    "legal_entity",
    "instrument_id",
    "asset_class",
    "buy_sell",
    "quantity",
    "market_value",
    "currency_x",
    "trading_book_flag",
    "delta",
    "isin",
    "issuer",
}

ALLOWED_GROUP_FIELDS = {
    "asset_class",
    "issuer",
    "sector",
    "rating",
    "trade_currency",
    "maturity_bucket",
    "book_id",
    "legal_entity",
    "exchange",
    "country",
}

ALLOWED_TREND_METRICS = {
    "market_value",
    "market_value_var",
    "component_var",
    "marginal_var",
    "delta",
    "cs01",
}


def iso_date(value: Optional[date]) -> Optional[str]:
    return value.isoformat() if value else None



def parse_bool(value: Any) -> Optional[bool]:
    if pd.isna(value):
        return None
    if isinstance(value, bool):
        return value
    value = str(value).strip().lower()
    if value in {"true", "1", "yes", "y"}:
        return True
    if value in {"false", "0", "no", "n"}:
        return False
    return None



def parse_date(value: Any) -> Optional[date]:
    if pd.isna(value) or value in (None, ""):
        return None
    ts = pd.to_datetime(value, errors="coerce")
    if pd.isna(ts):
        return None
    return ts.date()



def derive_maturity_bucket(as_of_date: Optional[date], maturity_date: Optional[date]) -> str:
    if not as_of_date or not maturity_date:
        return "N/A"
    years = max((maturity_date - as_of_date).days, 0) / 365.25
    if years < 1:
        return "<1Y"
    if years < 3:
        return "1Y-3Y"
    if years < 5:
        return "3Y-5Y"
    if years < 10:
        return "5Y-10Y"
    return "10Y+"



def load_json_file(path: str) -> Any:
    return json.loads(Path(path).read_text())



def pagination_params(default_page_size: int = 50, max_page_size: int = 500):
    page = max(int(request.args.get("page", 1)), 1)
    page_size = min(max(int(request.args.get("page_size", default_page_size)), 1), max_page_size)
    return page, page_size



def comma_separated_values(raw: Optional[str]) -> Optional[List[str]]:
    if not raw:
        return None
    return [item.strip() for item in raw.split(",") if item.strip()]



def write_audit_log(event_type: str, endpoint: Optional[str], details: Dict[str, Any], actor: str = "system"):
    entry = AuditLog(
        event_type=event_type,
        endpoint=endpoint,
        actor=actor,
        details=json.dumps(details, default=str),
    )
    db.session.add(entry)
    db.session.commit()
    return entry



def dataframe_quality_summary(df: pd.DataFrame) -> Dict[str, Any]:
    missing_columns = sorted(MANDATORY_COLUMNS - set(df.columns))
    duplicate_keys = int(df.duplicated(subset=["date", "trade_id"]).sum()) if {"date", "trade_id"}.issubset(df.columns) else None
    mandatory_nulls = {
        col: int(df[col].isna().sum())
        for col in sorted(MANDATORY_COLUMNS & set(df.columns))
    }
    invalid_asset_class = []
    if "asset_class" in df.columns:
        invalid_asset_class = sorted(
            set(df["asset_class"].dropna().astype(str).unique()) - {"Equity", "Bond"}
        )
    invalid_buy_sell = []
    if "buy_sell" in df.columns:
        invalid_buy_sell = sorted(
            set(df["buy_sell"].dropna().astype(str).unique()) - {"Buy", "Sell"}
        )
    return {
        "row_count": int(len(df)),
        "missing_mandatory_columns": missing_columns,
        "duplicate_date_trade_keys": duplicate_keys,
        "mandatory_null_counts": mandatory_nulls,
        "invalid_asset_class_values": invalid_asset_class,
        "invalid_buy_sell_values": invalid_buy_sell,
    }



def apply_common_filters(query, model):
    from .models import PositionSnapshot

    field_map = {
        "book_id": PositionSnapshot.book_id,
        "legal_entity": PositionSnapshot.legal_entity,
        "asset_class": PositionSnapshot.asset_class,
        "issuer": PositionSnapshot.issuer,
        "sector": PositionSnapshot.sector,
        "rating": PositionSnapshot.rating,
        "exchange": PositionSnapshot.exchange,
        "country": PositionSnapshot.country,
        "trade_currency": PositionSnapshot.trade_currency,
        "maturity_bucket": PositionSnapshot.maturity_bucket,
    }

    as_of_date = request.args.get("as_of_date")
    start_date = request.args.get("start_date")
    end_date = request.args.get("end_date")

    if as_of_date:
        query = query.filter(model.as_of_date == parse_date(as_of_date))
    else:
        if start_date:
            query = query.filter(model.as_of_date >= parse_date(start_date))
        if end_date:
            query = query.filter(model.as_of_date <= parse_date(end_date))

    for param, column in field_map.items():
        values = comma_separated_values(request.args.get(param))
        if values:
            query = query.filter(column.in_(values))

    return query



def latest_available_date(model):
    latest = db.session.query(db.func.max(model.as_of_date)).scalar()
    return latest
